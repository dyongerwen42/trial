import React, { useState, useEffect, useCallback, memo } from "react";
import {
  Box,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemText,
  Collapse,
  IconButton,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  TextField,
  Grid,
  Checkbox,
  FormControlLabel,
  Button,
} from "@mui/material";
import {
  ExpandMore as ExpandMoreIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
  InsertDriveFile as InsertDriveFileIcon,
  Download as DownloadIcon,
  Delete as DeleteIcon,
  ErrorOutline as ErrorOutlineIcon,
  ArrowForward as ArrowForwardIcon,
} from "@mui/icons-material";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import axios from "axios";

const ListItemComponent = memo(
  ({ space, openSpaces, handleToggleSpace, children }) => (
    <>
      <ListItem button onClick={() => handleToggleSpace(space.id)}>
        <ListItemText primary={space.name} />
        <ExpandMoreIcon />
      </ListItem>
      <Collapse in={openSpaces[space.id]} timeout="auto" unmountOnExit>
        <List component="div" disablePadding>
          {children}
        </List>
      </Collapse>
    </>
  )
);

const TaskItemComponent = memo(({ task, handleTaskClick }) => (
  <ListItem button onClick={() => handleTaskClick(task.id)}>
    <ListItemText
      primary={`${task.name} (Urgency: ${task.urgency}, Work Date: ${
        task.planned?.workDate
          ? new Date(task.planned.workDate).toLocaleDateString()
          : "N/A"
      })`}
    />
  </ListItem>
));

const getUrgencyColor = (urgency) => {
  switch (urgency) {
    case "1":
      return "green";
    case "2":
      return "lightgreen";
    case "3":
      return "yellow";
    case "4":
      return "orange";
    case "5":
      return "orangered";
    case "6":
      return "red";
    default:
      return "grey";
  }
};

const calculateRemainingCash = (
  initialCash,
  monthlyContribution,
  tasks,
  now = new Date()
) => {
  const startDate = new Date("2024-01-01");
  const monthsPassed =
    (now.getFullYear() - startDate.getFullYear()) * 12 +
    (now.getMonth() - startDate.getMonth());
  let remainingCash = initialCash + monthsPassed * monthlyContribution;

  let remainingCashList = [];
  let logArray = [];

  logArray.push(`Initial cash: ${initialCash}`);
  logArray.push(`Monthly contribution: ${monthlyContribution}`);
  logArray.push(`Months passed since start date: ${monthsPassed}`);
  logArray.push(
    `Total contributions added: ${monthsPassed * monthlyContribution}`
  );
  logArray.push(`Starting remaining cash: ${remainingCash}`);
  logArray.push("Tasks:");
  tasks.forEach((task, index) => {
    logArray.push(`  Task ${index + 1}: ${task.name}`);
  });

  // Sort tasks by planned work date
  tasks.sort((a, b) => {
    const dateA = new Date(a.planned?.workDate || Infinity);
    const dateB = new Date(b.planned?.workDate || Infinity);
    return dateA - dateB;
  });

  tasks.forEach((task, index) => {
    logArray.push(`Task ${index + 1}: ${task.name}`);
    logArray.push(`  Planned work date: ${task.planned?.workDate}`);

    const taskWorkDate = task.planned?.workDate
      ? new Date(task.planned.workDate)
      : null;
    if (taskWorkDate) {
      logArray.push(`  Task work date (parsed): ${taskWorkDate}`);
      logArray.push(`  Current date: ${now}`);
    }

    const price = parseFloat(
      task.planned?.invoicePrice ||
        task.planned?.offerPrice ||
        task.planned?.estimatedPrice ||
        0
    );
    logArray.push(`  Task price: ${price}`);
    logArray.push(`  Remaining cash before this task: ${remainingCash}`);

    if (taskWorkDate && taskWorkDate <= now) {
      // Task date is in the past or today
      remainingCash -= price;
      logArray.push(`  Task work date is in the past or today. Cash deducted.`);
    } else if (taskWorkDate) {
      // Task date is in the future
      const futureMonths =
        (taskWorkDate.getFullYear() - now.getFullYear()) * 12 +
        (taskWorkDate.getMonth() - now.getMonth());
      remainingCash += futureMonths * monthlyContribution - price;
      logArray.push(
        `  Task work date is in the future. Future contributions added and cash deducted.`
      );
    } else {
      logArray.push(`  Task work date is not set. Remaining cash unchanged.`);
    }

    logArray.push(`  Remaining cash after this task: ${remainingCash}`);
    remainingCashList.push(Number(remainingCash));
  });

  logArray.push(`Remaining cash list: ${JSON.stringify(remainingCashList)}`);

  console.log(logArray.join("\n"));

  return remainingCashList;
};

const TaskComponent = memo(
  ({
    task,
    elementId,
    elementName,
    spaceName,
    handleChange,
    handleFileChange,
    handleFileDelete,
    expandedAccordion,
    setExpandedAccordion,
    remainingCash,
  }) => {
    const isExpanded = expandedAccordion === `${elementId}-${task.id}`;
    const canMarkDone = task.planned?.invoiceFiles?.length > 0;
    const weeksRemaining = Math.round(
      (new Date(task.ultimateDate) - new Date()) / (1000 * 60 * 60 * 24 * 7)
    );

    return (
      <Accordion
        key={task.id}
        sx={{
          mb: 2,
          border: "1px solid #ddd",
          borderRadius: "8px",
          boxShadow: 1,
        }}
        expanded={isExpanded}
        onChange={() =>
          setExpandedAccordion(isExpanded ? null : `${elementId}-${task.id}`)
        }
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: "primary.main" }} />}
          aria-controls={`panel-content-${task.id}`}
          id={`panel-header-${task.id}`}
          sx={{
            backgroundColor: "#f5f5f5",
            borderBottom: "1px solid #ddd",
            "&:hover": {
              backgroundColor: "#e0e0e0",
            },
            padding: "0 16px",
          }}
        >
          <Box sx={{ width: "100%" }}>
            <Grid container alignItems="center" spacing={2}>
              <Grid item xs={3}>
                <Box display="flex" alignItems="center">
                  <Typography variant="body2" color="textSecondary">
                    {spaceName}
                  </Typography>
                  <ArrowForwardIcon sx={{ mx: 0.5, color: "textSecondary" }} />
                  <Typography variant="body2" color="textSecondary">
                    {elementName}
                  </Typography>
                  <ArrowForwardIcon sx={{ mx: 0.5, color: "textSecondary" }} />
                  <Typography variant="body2">{task.name}</Typography>
                </Box>
              </Grid>
              <Grid item xs={2}>
                <DatePicker
                  selected={
                    task.planned?.workDate
                      ? new Date(task.planned.workDate)
                      : null
                  }
                  onChange={(date) =>
                    handleChange(task.id, elementId, date, "workDate")
                  }
                  dateFormat="MM/yyyy"
                  showMonthYearPicker
                  customInput={
                    <TextField
                      variant="outlined"
                      size="small"
                      label="Work Date"
                      sx={{ width: "100%" }}
                    />
                  }
                />
              </Grid>
              <Grid item xs={1}>
                <Box
                  sx={{
                    width: 24,
                    height: 24,
                    borderRadius: "50%",
                    backgroundColor: getUrgencyColor(task.urgency),
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "white",
                    fontSize: 12,
                    fontWeight: "bold",
                  }}
                >
                  {task.urgency}
                </Box>
              </Grid>
              <Grid item xs={2}>
                <DatePicker
                  selected={new Date(task.ultimateDate)}
                  onChange={(date) =>
                    handleChange(task.id, elementId, date, "ultimateDate")
                  }
                  dateFormat="MM/dd/yyyy"
                  customInput={
                    <TextField
                      variant="outlined"
                      size="small"
                      label="Ultimate Date"
                      sx={{ width: "100%" }}
                    />
                  }
                />
              </Grid>
              <Grid item xs={2} display="flex" justifyContent="center">
                {weeksRemaining <= 12 && !task.planned?.offerAccepted && (
                  <ErrorOutlineIcon color="error" sx={{ fontSize: 20 }} />
                )}
              </Grid>
              <Grid item xs={2}>
                <Typography variant="body2" color="primary">
                  Remaining: €{remainingCash.toFixed(2)}
                </Typography>
              </Grid>
            </Grid>
          </Box>
        </AccordionSummary>

        <AccordionDetails>
          {isExpanded && (
            <Box
              sx={{
                p: 3,
                backgroundColor: "#f3f4f6",
                borderRadius: "8px",
                boxShadow: 2,
              }}
            >
              <Typography
                variant="h6"
                sx={{ mb: 3, fontWeight: "bold", color: "primary.main" }}
              >
                {task.description}
              </Typography>
              <TextField
                fullWidth
                type="number"
                label="Estimated Price"
                value={task.planned?.estimatedPrice || ""}
                onChange={(e) =>
                  handleChange(
                    task.id,
                    elementId,
                    e.target.value,
                    "estimatedPrice"
                  )
                }
                variant="outlined"
                sx={{ mb: 3, backgroundColor: "white", borderRadius: "4px" }}
                InputLabelProps={{ style: { color: "#555" } }}
              />
              <TextField
                fullWidth
                type="number"
                label="Offer Price"
                value={task.planned?.offerPrice || ""}
                onChange={(e) =>
                  handleChange(task.id, elementId, e.target.value, "offerPrice")
                }
                variant="outlined"
                sx={{ mb: 3, backgroundColor: "white", borderRadius: "4px" }}
                InputLabelProps={{ style: { color: "#555" } }}
              />
              <TextField
                fullWidth
                type="number"
                label="Invoice Price"
                value={task.planned?.invoicePrice || ""}
                onChange={(e) =>
                  handleChange(
                    task.id,
                    elementId,
                    e.target.value,
                    "invoicePrice"
                  )
                }
                variant="outlined"
                sx={{ mb: 3, backgroundColor: "white", borderRadius: "4px" }}
                InputLabelProps={{ style: { color: "#555" } }}
              />
              <TextField
                fullWidth
                label="Comment"
                value={task.planned?.comment || ""}
                onChange={(e) =>
                  handleChange(task.id, elementId, e.target.value, "comment")
                }
                variant="outlined"
                multiline
                sx={{ mb: 3, backgroundColor: "white", borderRadius: "4px" }}
                InputLabelProps={{ style: { color: "#555" } }}
              />
              <TextField
                fullWidth
                label="Urgency"
                value={task.urgency}
                variant="outlined"
                sx={{ mb: 3, backgroundColor: "white", borderRadius: "4px" }}
                disabled
                InputLabelProps={{ style: { color: "#555" } }}
              />
              <Box sx={{ mb: 3 }}>
                <Typography
                  variant="subtitle1"
                  sx={{ mb: 1, fontWeight: "bold" }}
                >
                  Upload Offer
                </Typography>
                <input
                  type="file"
                  multiple
                  onChange={(e) =>
                    handleFileChange(
                      task.id,
                      elementId,
                      e.target.files,
                      "offer"
                    )
                  }
                  style={{ marginBottom: "16px", display: "block" }}
                />
                {task.planned?.offerFiles &&
                  task.planned.offerFiles.map((file, fileIndex) => (
                    <Box
                      display="flex"
                      alignItems="center"
                      sx={{ mb: 2 }}
                      key={fileIndex}
                    >
                      <a
                        href={`http://localhost:5000/${file}`}
                        download
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{ marginRight: "8px" }}
                      >
                        <InsertDriveFileIcon
                          style={{ fontSize: 40, color: "#2196f3" }}
                        />
                      </a>
                      <IconButton
                        size="small"
                        onClick={() => {
                          const link = document.createElement("a");
                          link.href = `http://localhost:5000/${file}`;
                          link.download = file;
                          link.click();
                        }}
                      >
                        <DownloadIcon />
                      </IconButton>
                      <IconButton
                        size="small"
                        onClick={() =>
                          handleFileDelete(task.id, elementId, file, "offer")
                        }
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  ))}
              </Box>
              <Box sx={{ mb: 3 }}>
                <Typography
                  variant="subtitle1"
                  sx={{ mb: 1, fontWeight: "bold" }}
                >
                  Upload Invoice
                </Typography>
                <input
                  type="file"
                  multiple
                  onChange={(e) =>
                    handleFileChange(
                      task.id,
                      elementId,
                      e.target.files,
                      "invoice"
                    )
                  }
                  style={{ marginBottom: "16px", display: "block" }}
                />
                {task.planned?.invoiceFiles &&
                  task.planned.invoiceFiles.map((file, fileIndex) => (
                    <Box
                      display="flex"
                      alignItems="center"
                      sx={{ mb: 2 }}
                      key={fileIndex}
                    >
                      <a
                        href={`http://localhost:5000/${file}`}
                        download
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{ marginRight: "8px" }}
                      >
                        <InsertDriveFileIcon
                          style={{ fontSize: 40, color: "#2196f3" }}
                        />
                      </a>
                      <IconButton
                        size="small"
                        onClick={() => {
                          const link = document.createElement("a");
                          link.href = `http://localhost:5000/${file}`;
                          link.download = file;
                          link.click();
                        }}
                      >
                        <DownloadIcon />
                      </IconButton>
                      <IconButton
                        size="small"
                        onClick={() =>
                          handleFileDelete(task.id, elementId, file, "invoice")
                        }
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  ))}
              </Box>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={task.inspectionDone}
                    onChange={(e) =>
                      handleChange(
                        task.id,
                        elementId,
                        e.target.checked,
                        "inspectionDone"
                      )
                    }
                    disabled={!canMarkDone}
                  />
                }
                label="Done"
                sx={{ mb: 3 }}
              />
              <FormControlLabel
                control={
                  <Checkbox
                    checked={task.planned?.offerAccepted || false}
                    onChange={(e) =>
                      handleChange(
                        task.id,
                        elementId,
                        e.target.checked,
                        "offerAccepted"
                      )
                    }
                  />
                }
                label="Offer Accepted"
                sx={{ mb: 3 }}
              />
              {task.planned?.offerAccepted && (
                <>
                  <Typography
                    variant="subtitle1"
                    sx={{ mt: 3, mb: 2, fontWeight: "bold" }}
                  >
                    Real Planning Dates
                  </Typography>
                  <DatePicker
                    selected={
                      task.planned?.startDate
                        ? new Date(task.planned.startDate)
                        : null
                    }
                    onChange={(date) =>
                      handleChange(task.id, elementId, date, "startDate")
                    }
                    dateFormat="MM/yyyy"
                    showMonthYearPicker
                    customInput={
                      <TextField
                        variant="outlined"
                        label="Start Date"
                        fullWidth
                        sx={{
                          mb: 2,
                          backgroundColor: "white",
                          borderRadius: "4px",
                        }}
                      />
                    }
                  />
                  <DatePicker
                    selected={
                      task.planned?.endDate
                        ? new Date(task.planned.endDate)
                        : null
                    }
                    onChange={(date) =>
                      handleChange(task.id, elementId, date, "endDate")
                    }
                    dateFormat="MM/yyyy"
                    showMonthYearPicker
                    customInput={
                      <TextField
                        variant="outlined"
                        label="End Date"
                        fullWidth
                        sx={{
                          mb: 2,
                          backgroundColor: "white",
                          borderRadius: "4px",
                        }}
                      />
                    }
                  />
                </>
              )}
            </Box>
          )}
        </AccordionDetails>
      </Accordion>
    );
  }
);

const Planning = ({
  globalSpaces = [],
  globalElements = [],
  setGlobalElements,
  cashInfo,
}) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [openElements, setOpenElements] = useState({});
  const [openSpaces, setOpenSpaces] = useState({});
  const [expandedAccordion, setExpandedAccordion] = useState(null);
  const [allTasks, setAllTasks] = useState([]);
  const [remainingCashList, setRemainingCashList] = useState([]);

  useEffect(() => {
    const allTasks = globalElements.flatMap((element) =>
      element.inspectionReport.flatMap((report) =>
        report.tasks.map((task) => ({
          ...task,
          elementId: element.id,
          elementName: element.name,
          spaceName:
            globalSpaces.find((space) => space.id === element.spaceId)?.name ||
            "Unknown Space",
        }))
      )
    );

    allTasks.sort(
      (a, b) =>
        new Date(a.planned?.workDate || Infinity) -
        new Date(b.planned?.workDate || Infinity)
    );

    setAllTasks(allTasks);

    const updatedRemainingCashList = calculateRemainingCash(
      parseFloat(cashInfo.currentCash),
      parseFloat(cashInfo.monthlyContribution),
      allTasks
    );
    setRemainingCashList(updatedRemainingCashList);
  }, [globalElements, cashInfo, globalSpaces]);

  const handleToggleElement = useCallback((elementId) => {
    setOpenElements((prev) => ({ ...prev, [elementId]: !prev[elementId] }));
  }, []);

  const handleToggleSpace = useCallback((spaceId) => {
    setOpenSpaces((prev) => ({ ...prev, [spaceId]: !prev[spaceId] }));
  }, []);

  const handleTaskClick = useCallback(
    (taskId, elementId) => {
      setGlobalElements((prevElements) => {
        const elementIndex = prevElements.findIndex(
          (element) => element.id === elementId
        );
        if (elementIndex === -1) return prevElements;

        const updatedElements = [...prevElements];
        const updatedElement = { ...updatedElements[elementIndex] };

        const reportIndex = updatedElement.inspectionReport.findIndex(
          (report) => report.tasks.some((task) => task.id === taskId)
        );
        if (reportIndex === -1) return prevElements;

        const updatedReport = {
          ...updatedElement.inspectionReport[reportIndex],
        };

        const taskIndex = updatedReport.tasks.findIndex(
          (task) => task.id === taskId
        );
        if (taskIndex === -1) return prevElements;

        const updatedTasks = [...updatedReport.tasks];
        const updatedTask = { ...updatedTasks[taskIndex] };

        updatedTask.planned = {
          workDate: new Date(),
          estimatedPrice: "",
          offerPrice: "",
          invoicePrice: "",
          comment: "",
          offerFiles: [],
          invoiceFiles: [],
          offerAccepted: false,
        };

        updatedTasks[taskIndex] = updatedTask;
        updatedReport.tasks = updatedTasks;
        updatedElement.inspectionReport[reportIndex] = updatedReport;
        updatedElements[elementIndex] = updatedElement;

        return updatedElements;
      });
    },
    [setGlobalElements]
  );

  const handleChange = useCallback(
    (taskId, elementId, value, field) => {
      setGlobalElements((prevElements) => {
        const elementIndex = prevElements.findIndex(
          (element) => element.id === elementId
        );
        if (elementIndex === -1) return prevElements;

        const updatedElements = [...prevElements];
        const updatedElement = { ...updatedElements[elementIndex] };

        const reportIndex = updatedElement.inspectionReport.findIndex(
          (report) => report.tasks.some((task) => task.id === taskId)
        );
        if (reportIndex === -1) return prevElements;

        const updatedReport = {
          ...updatedElement.inspectionReport[reportIndex],
        };

        const taskIndex = updatedReport.tasks.findIndex(
          (task) => task.id === taskId
        );
        if (taskIndex === -1) return prevElements;

        const updatedTasks = [...updatedReport.tasks];
        const updatedTask = { ...updatedTasks[taskIndex] };

        updatedTask.planned = {
          ...updatedTask.planned,
          [field]: value,
        };
        if (field === "inspectionDone") {
          updatedTask.inspectionDone = value;
        } else if (field === "ultimateDate") {
          updatedTask.ultimateDate = value;
        }

        updatedTasks[taskIndex] = updatedTask;
        updatedReport.tasks = updatedTasks;
        updatedElement.inspectionReport[reportIndex] = updatedReport;
        updatedElements[elementIndex] = updatedElement;

        return updatedElements;
      });

      setAllTasks((prevTasks) => {
        const updatedTasks = prevTasks.map((task) =>
          task.id === taskId
            ? { ...task, planned: { ...task.planned, [field]: value } }
            : task
        );
        const sortedTasks = updatedTasks.sort(
          (a, b) =>
            new Date(a.planned?.workDate || Infinity) -
            new Date(b.planned?.workDate || Infinity)
        );
        const updatedRemainingCashList = calculateRemainingCash(
          parseFloat(cashInfo.currentCash),
          parseFloat(cashInfo.monthlyContribution),
          sortedTasks
        );
        setRemainingCashList(updatedRemainingCashList);
        return sortedTasks;
      });
    },
    [setGlobalElements, cashInfo]
  );

  const handleFileChange = useCallback(
    async (taskId, elementId, files, type) => {
      const formData = new FormData();
      Array.from(files).forEach((file) => {
        formData.append("file", file);
      });

      const { data } = await axios.post(
        "http://localhost:5000/upload",
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );

      setGlobalElements((prevElements) => {
        const elementIndex = prevElements.findIndex(
          (element) => element.id === elementId
        );
        if (elementIndex === -1) return prevElements;

        const updatedElements = [...prevElements];
        const updatedElement = { ...updatedElements[elementIndex] };

        const reportIndex = updatedElement.inspectionReport.findIndex(
          (report) => report.tasks.some((task) => task.id === taskId)
        );
        if (reportIndex === -1) return prevElements;

        const updatedReport = {
          ...updatedElement.inspectionReport[reportIndex],
        };

        const taskIndex = updatedReport.tasks.findIndex(
          (task) => task.id === taskId
        );
        if (taskIndex === -1) return prevElements;

        const updatedTasks = [...updatedReport.tasks];
        const updatedTask = { ...updatedTasks[taskIndex] };

        updatedTask.planned = {
          ...updatedTask.planned,
          [`${type}Files`]: [
            ...(updatedTask.planned[`${type}Files`] || []),
            data.filePath,
          ],
        };

        updatedTasks[taskIndex] = updatedTask;
        updatedReport.tasks = updatedTasks;
        updatedElement.inspectionReport[reportIndex] = updatedReport;
        updatedElements[elementIndex] = updatedElement;

        return updatedElements;
      });

      setAllTasks((prevTasks) => {
        const updatedTasks = prevTasks.map((task) =>
          task.id === taskId
            ? {
                ...task,
                planned: {
                  ...task.planned,
                  [`${type}Files`]: [
                    ...(task.planned[`${type}Files`] || []),
                    data.filePath,
                  ],
                },
              }
            : task
        );
        const sortedTasks = updatedTasks.sort(
          (a, b) =>
            new Date(a.planned?.workDate || Infinity) -
            new Date(b.planned?.workDate || Infinity)
        );
        const updatedRemainingCashList = calculateRemainingCash(
          parseFloat(cashInfo.currentCash),
          parseFloat(cashInfo.monthlyContribution),
          sortedTasks
        );
        setRemainingCashList(updatedRemainingCashList);
        return sortedTasks;
      });
    },
    [setGlobalElements, cashInfo]
  );

  const handleFileDelete = useCallback(
    (taskId, elementId, filePath, type) => {
      setGlobalElements((prevElements) => {
        const elementIndex = prevElements.findIndex(
          (element) => element.id === elementId
        );
        if (elementIndex === -1) return prevElements;

        const updatedElements = [...prevElements];
        const updatedElement = { ...updatedElements[elementIndex] };

        const reportIndex = updatedElement.inspectionReport.findIndex(
          (report) => report.tasks.some((task) => task.id === taskId)
        );
        if (reportIndex === -1) return prevElements;

        const updatedReport = {
          ...updatedElement.inspectionReport[reportIndex],
        };

        const taskIndex = updatedReport.tasks.findIndex(
          (task) => task.id === taskId
        );
        if (taskIndex === -1) return prevElements;

        const updatedTasks = [...updatedReport.tasks];
        const updatedTask = { ...updatedTasks[taskIndex] };

        updatedTask.planned = {
          ...updatedTask.planned,
          [`${type}Files`]: updatedTask.planned[`${type}Files`].filter(
            (file) => file !== filePath
          ),
        };

        updatedTasks[taskIndex] = updatedTask;
        updatedReport.tasks = updatedTasks;
        updatedElement.inspectionReport[reportIndex] = updatedReport;
        updatedElements[elementIndex] = updatedElement;

        return updatedElements;
      });

      setAllTasks((prevTasks) => {
        const updatedTasks = prevTasks.map((task) =>
          task.id === taskId
            ? {
                ...task,
                planned: {
                  ...task.planned,
                  [`${type}Files`]: task.planned[`${type}Files`].filter(
                    (file) => file !== filePath
                  ),
                },
              }
            : task
        );
        const sortedTasks = updatedTasks.sort(
          (a, b) =>
            new Date(a.planned?.workDate || Infinity) -
            new Date(b.planned?.workDate || Infinity)
        );
        const updatedRemainingCashList = calculateRemainingCash(
          parseFloat(cashInfo.currentCash),
          parseFloat(cashInfo.monthlyContribution),
          sortedTasks
        );
        setRemainingCashList(updatedRemainingCashList);
        return sortedTasks;
      });
    },
    [setGlobalElements, cashInfo]
  );

  const renderTasks = useCallback(
    (tasks, remainingCashList) => {
      return tasks.map((task, index) => (
        <TaskComponent
          key={task.id}
          task={task}
          elementId={task.elementId}
          elementName={task.elementName}
          spaceName={task.spaceName}
          handleChange={handleChange}
          handleFileChange={handleFileChange}
          handleFileDelete={handleFileDelete}
          expandedAccordion={expandedAccordion}
          setExpandedAccordion={setExpandedAccordion}
          remainingCash={remainingCashList[index]}
        />
      ));
    },
    [
      expandedAccordion,
      handleChange,
      handleFileChange,
      handleFileDelete,
      remainingCashList,
    ]
  );

  return (
    <Box display="flex">
      {isSidebarOpen && (
        <Paper
          sx={{
            width: "25%",
            maxHeight: "100vh",
            overflowY: "auto",
            p: 2,
            boxShadow: 3,
            borderRadius: "8px",
          }}
        >
          <Typography variant="h6" gutterBottom>
            Inspection Items
          </Typography>
          <List>
            {globalSpaces.map((space) => {
              const spaceElements = globalElements.filter(
                (element) => element.spaceId === space.id
              );
              const hasUnplannedTasks = spaceElements.some((element) =>
                element.inspectionReport.some((report) =>
                  report.tasks.some((task) => !task.planned)
                )
              );
              if (!hasUnplannedTasks) return null;

              return (
                <ListItemComponent
                  key={space.id}
                  space={space}
                  openSpaces={openSpaces}
                  handleToggleSpace={handleToggleSpace}
                >
                  {spaceElements.map((element) => {
                    const unplannedTasks = element.inspectionReport.flatMap(
                      (report) => report.tasks.filter((task) => !task.planned)
                    );
                    if (unplannedTasks.length === 0) return null;

                    return (
                      <React.Fragment key={element.id}>
                        <ListItem
                          button
                          onClick={() => handleToggleElement(element.id)}
                          sx={{ pl: 4 }}
                        >
                          <ListItemText primary={element.name} />
                          <ExpandMoreIcon />
                        </ListItem>
                        <Collapse
                          in={openElements[element.id]}
                          timeout="auto"
                          unmountOnExit
                        >
                          <List component="div" disablePadding>
                            {unplannedTasks.map((task) => (
                              <TaskItemComponent
                                key={task.id}
                                task={task}
                                handleTaskClick={() =>
                                  handleTaskClick(task.id, element.id)
                                }
                              />
                            ))}
                          </List>
                        </Collapse>
                      </React.Fragment>
                    );
                  })}
                </ListItemComponent>
              );
            })}
          </List>
        </Paper>
      )}
      <Box
        component="section"
        sx={{
          width: isSidebarOpen ? "75%" : "100%",
          p: 2,
          maxHeight: "100vh",
          overflowY: "auto",
        }}
      >
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          mb={2}
        >
          <IconButton
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            sx={{ mb: 2 }}
          >
            {isSidebarOpen ? <ChevronLeftIcon /> : <ChevronRightIcon />}
          </IconButton>
          <Typography variant="h5">Planning</Typography>
        </Box>
        {renderTasks(allTasks, remainingCashList)}
      </Box>
    </Box>
  );
};

export default Planning;
