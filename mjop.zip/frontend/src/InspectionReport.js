import React, { useState, useEffect, useCallback } from 'react';
import {
  Tabs,
  Tab,
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  Grid,
  IconButton,
  MenuItem,
  Modal,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
  FormControl,
  Select,
  List,
  ListItem,
  ListItemText,
} from '@mui/material';
import {
  CheckCircle,
  CheckCircleOutline,
  Close,
  Delete,
  Error,
  Warning,
  AddPhotoAlternate as AddPhotoAlternateIcon,
  InsertDriveFile as InsertDriveFileIcon,
  Description as DescriptionIcon,
  Clear as ClearIcon,
  Download as DownloadIcon,
} from '@mui/icons-material';
import { v4 as uuidv4 } from 'uuid';
import axios from 'axios';
import inspectionTasks from './inspectionTasks.json';

const getMistakeCategories = (elementType, material) => {
  const task = inspectionTasks.find((task) => task.name === elementType);
  if (!task || !task.gebreken || !task.gebreken[material]) {
    return {};
  }
  return task.gebreken[material];
};

const InspectionTable = ({
  handleOpenModal,
  handleInspectionChange,
  handleDeleteInspection,
  handleInspectionDoneChange,
  handleRequestInspection,
  handleRequestInspectionForAll,
  items = [],
  filter,
  setFilter,
  t,
}) => {
  const getStatusIcon = (inspectionDone, inspectionDate) => {
    const currentDate = new Date();
    const inspectionDateObj = inspectionDate ? new Date(inspectionDate) : null;
    const monthDiff =
      inspectionDateObj
        ? (inspectionDateObj.getFullYear() - currentDate.getFullYear()) * 12 +
          (inspectionDateObj.getMonth() - currentDate.getMonth())
        : null;

    if (inspectionDone) {
      return <CheckCircle style={{ color: 'green' }} />;
    }
    if (monthDiff <= 0) {
      return <Error style={{ color: 'red' }} />;
    } else if (monthDiff <= 1) {
      return <Warning style={{ color: 'orange' }} />;
    }
    return <CheckCircleOutline style={{ color: 'green' }} />;
  };

  const filteredItems = items.flatMap((item) =>
    item.inspectionReport
      .filter((report) => {
        if (filter === 'todo') return !report.inspectionDone;
        if (filter === 'done') return report.inspectionDone;
        return true;
      })
      .map((report) => ({ ...report, elementName: item.name, elementId: item.id }))
  );

  return (
    <Box>
      <Box display="flex" justifyContent="flex-end" mb={2}>
        <Typography variant="subtitle1" mr={2}>
          {t('generateMJOP.filter')}
        </Typography>
        <Select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          displayEmpty
          inputProps={{ 'aria-label': 'Without label' }}
        >
          <MenuItem value="todo">{t('generateMJOP.filterTodo')}</MenuItem>
          <MenuItem value="done">{t('generateMJOP.filterDone')}</MenuItem>
          <MenuItem value="all">{t('generateMJOP.filterAll')}</MenuItem>
        </Select>
      </Box>
      <Box display="flex" justifyContent="flex-end" mb={2}>
        <Button onClick={handleRequestInspectionForAll}>
          {t('generateMJOP.requestInspectionForAll')}
        </Button>
      </Box>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>{t('generateMJOP.name')}</TableCell>
              <TableCell>{t('generateMJOP.description')}</TableCell>
              <TableCell>{t('generateMJOP.inspectionDate')}</TableCell>
              <TableCell>{t('generateMJOP.status')}</TableCell>
              <TableCell>{t('generateMJOP.actions')}</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredItems.map((report) => (
              <TableRow key={report.id}>
                <TableCell>{report.elementName}</TableCell>
                <TableCell>{report.description}</TableCell>
                <TableCell>
                  <TextField
                    type="date"
                    value={
                      report.inspectionDate
                        ? new Date(report.inspectionDate).toISOString().split('T')[0]
                        : ''
                    }
                    onChange={(e) =>
                      handleInspectionChange(
                        report.elementId,
                        report.id,
                        'inspectionDate',
                        e.target.value
                      )
                    }
                    fullWidth
                  />
                </TableCell>
                <TableCell>
                  <Box display="flex" alignItems="center">
                    {getStatusIcon(report.inspectionDone, report.inspectionDate)}
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={report.inspectionDone}
                          onChange={(e) =>
                            handleInspectionDoneChange(
                              report.elementId,
                              report.id,
                              e.target.checked
                            )
                          }
                          color="primary"
                        />
                      }
                      label={t('generateMJOP.inspectionDone')}
                    />
                  </Box>
                </TableCell>
                <TableCell>
                  <Box display="flex" gap={1}>
                    <Button
                      onClick={() =>
                        handleOpenModal(
                          report.elementId,
                          report || { id: uuidv4(), tasks: [] }
                        )
                      }
                    >
                      {t('generateMJOP.inspect')}
                    </Button>
                    <Button
                      onClick={() => handleDeleteInspection(report.elementId, report.id)}
                    >
                      {t('generateMJOP.delete')}
                    </Button>
                    <Button
                      onClick={() => handleRequestInspection(report.elementId, report.id)}
                    >
                      {t('generateMJOP.requestInspection')}
                    </Button>
                  </Box>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};


const InspectionModal = ({
  currentElementId,
  currentInspection,
  handleCloseModal,
  handleInspectionChange,
  t,
  tasks,
  handleTaskChange,
  handleAddTask,
  handleDeleteTask,
  handleTaskDocumentChange,
  handleTaskImageChange,
  editableFields = {},
  globalElements,
}) => {
  const [tabIndex, setTabIndex] = useState(0);

  const [inspectionState, setInspectionState] = useState({
    name: '',
    description: '',
    condition: '',
    urgency: '',
    elementType: '',
    material: '',
    damage: '',
    elementFunction: '',
    surfaceArea: '',
    unit: '',
    inspectionDate: '',
    estimatedPrice: '',
    remarks: '',
    images: [],
    documents: [],
  });

  const [imagePreviews, setImagePreviews] = useState([]);
  const [documentPreviews, setDocumentPreviews] = useState([]);
  const [mistakes, setMistakes] = useState([]);
  const [gebreken, setGebreken] = useState({});

  useEffect(() => {
    if (currentInspection) {
      setInspectionState({
        name: currentInspection.name || '',
        description: currentInspection.description || '',
        condition: currentInspection.condition || '',
        urgency: currentInspection.urgency || '',
        elementType: currentInspection.elementType || '',
        material: currentInspection.material || '',
        damage: currentInspection.damage || '',
        elementFunction: currentInspection.elementFunction || '',
        surfaceArea: currentInspection.surfaceArea || '',
        unit: currentInspection.unit || '',
        inspectionDate: currentInspection.inspectionDate || '',
        estimatedPrice: currentInspection.estimatedPrice || '',
        remarks: currentInspection.remarks || '',
        images: currentInspection.images || [],
        documents: currentInspection.documents || [],
      });

      const imagePreviews = (currentInspection.images || []).map((file) => {
        if (typeof file === 'string') {
          return `http://localhost:5000/${file}`;
        } else if (file instanceof File) {
          return URL.createObjectURL(file);
        } else {
          return null;
        }
      }).filter((src) => src !== null);

      setImagePreviews(imagePreviews);

      const documentPreviews = (currentInspection.documents || []).map((file) => {
        if (typeof file === 'string') {
          return `http://localhost:5000/${file}`;
        } else if (file instanceof File) {
          return URL.createObjectURL(file);
        } else {
          return null;
        }
      }).filter((src) => src !== null);

      setDocumentPreviews(documentPreviews);

      setMistakes(currentInspection.mistakes || []);

      const currentElement = globalElements.find(el => el.id === currentElementId);
      if (currentElement) {
        setGebreken(currentElement.gebreken || {});
      }
    }
  }, [currentInspection, currentElementId, globalElements]);

  const handleFieldChange = (field, value) => {
    setInspectionState((prev) => ({
      ...prev,
      [field]: value,
    }));
    handleInspectionChange(currentElementId, currentInspection.id, field, value);
  };

  const handleAddImages = async (newImages) => {
    const formData = new FormData();
    newImages.forEach((image) => {
      formData.append('file', image);
    });

    const { data } = await axios.post('http://localhost:5000/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });

    const updatedImages = [...inspectionState.images, data.filePath];
    setInspectionState((prev) => ({
      ...prev,
      images: updatedImages,
    }));
    handleInspectionChange(currentElementId, currentInspection.id, 'images', updatedImages);

    const updatedImagePreviews = [...imagePreviews, `http://localhost:5000/${data.filePath}`];
    setImagePreviews(updatedImagePreviews);
  };

  const handleAddDocuments = async (newDocuments) => {
    const formData = new FormData();
    newDocuments.forEach((doc) => {
      formData.append('file', doc);
    });

    const { data } = await axios.post('http://localhost:5000/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });

    const updatedDocuments = [...inspectionState.documents, data.filePath];
    setInspectionState((prev) => ({
      ...prev,
      documents: updatedDocuments,
    }));
    handleInspectionChange(currentElementId, currentInspection.id, 'documents', updatedDocuments);

    const updatedDocumentPreviews = [...documentPreviews, `http://localhost:5000/${data.filePath}`];
    setDocumentPreviews(updatedDocumentPreviews);
  };

  const handleClearImage = (index) => {
    const updatedImages = inspectionState.images.filter((_, i) => i !== index);
    setInspectionState((prev) => ({
      ...prev,
      images: updatedImages,
    }));
    handleInspectionChange(currentElementId, currentInspection.id, 'images', updatedImages);

    const updatedImagePreviews = imagePreviews.filter((_, i) => i !== index);
    setImagePreviews(updatedImagePreviews);
  };

  const handleClearDocument = (index) => {
    const updatedDocuments = inspectionState.documents.filter((_, i) => i !== index);
    setInspectionState((prev) => ({
      ...prev,
      documents: updatedDocuments,
    }));
    handleInspectionChange(currentElementId, currentInspection.id, 'documents', updatedDocuments);

    const updatedDocumentPreviews = documentPreviews.filter((_, i) => i !== index);
    setDocumentPreviews(updatedDocumentPreviews);
  };

  const handleTaskClearImage = (taskId, imageIndex) => {
    handleTaskChange(taskId, 'images', (prevImages) =>
      prevImages.filter((_, i) => i !== imageIndex)
    );
  };

  const handleTaskClearDocument = (taskId, docIndex) => {
    handleTaskChange(taskId, 'documents', (prevDocuments) =>
      prevDocuments.filter((_, i) => i !== docIndex)
    );
  };

  const handleAddMistake = (category, severity) => {
    setMistakes((prevMistakes) => [
      ...prevMistakes,
      { id: uuidv4(), category, severity, omvang: '', description: '' },
    ]);
  };

  const handleMistakeChange = (index, field, value) => {
    const updatedMistakes = mistakes.map((mistake, i) =>
      i === index ? { ...mistake, [field]: value } : mistake
    );
    setMistakes(updatedMistakes);
    handleInspectionChange(currentElementId, currentInspection.id, 'mistakes', updatedMistakes);
  };

  const getFileIcon = (fileType) => {
    switch (fileType) {
      case 'pdf':
        return <InsertDriveFileIcon style={{ fontSize: 40 }} />;
      case 'msword':
      case 'vnd.openxmlformats-officedocument.wordprocessingml.document':
        return <DescriptionIcon style={{ fontSize: 40 }} />;
      default:
        return <InsertDriveFileIcon style={{ fontSize: 40 }} />;
    }
  };

  const renderMistakeList = (severity) => {
    return (gebreken[severity] || []).map((mistake, index) => (
      <ListItem
        button
        key={index}
        onClick={() => handleAddMistake(mistake, severity)}
        sx={{
          borderRadius: 1,
          '&:hover': {
            backgroundColor: 'primary.light',
          },
        }}
      >
        <ListItemText primary={mistake} />
      </ListItem>
    ));
  };

  return (
    <Modal
      open={!!currentInspection}
      onClose={handleCloseModal}
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: '100vw',
      }}
    >
      <Paper
        sx={{
          width: '90vw',
          height: '90vh',
          overflow: 'hidden',
          borderRadius: 2,
          boxShadow: 4,
        }}
      >
        <Box display="flex" flexDirection="column" height="100%">
          <Box display="flex" justifyContent="space-between" alignItems="center" p={2} borderBottom="1px solid #ddd">
            <Typography variant="h6">
              {t('generateMJOP.inspectElement')} - {inspectionState.name}
            </Typography>
            <IconButton onClick={handleCloseModal}>
              <Close />
            </IconButton>
          </Box>
          <Tabs
            value={tabIndex}
            onChange={(e, newIndex) => setTabIndex(newIndex)}
            indicatorColor="primary"
            textColor="primary"
            variant="fullWidth"
            sx={{ borderBottom: 1, borderColor: 'divider' }}
          >
            <Tab label={t('generateMJOP.generalInformation')} />
            <Tab label={t('generateMJOP.mistakes')} />
            <Tab label={t('generateMJOP.tasks')} />
          </Tabs>
          <Box flex={1} overflow="auto">
            {tabIndex === 0 && (
              <Box p={4}>
                <Grid container spacing={3}>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label={t('generateMJOP.name')}
                      value={inspectionState.name}
                      onChange={(e) => handleFieldChange('name', e.target.value)}
                      InputProps={{
                        readOnly: !editableFields.name,
                      }}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      multiline
                      label={t('generateMJOP.description')}
                      value={inspectionState.description}
                      onChange={(e) => handleFieldChange('description', e.target.value)}
                      InputProps={{
                        readOnly: !editableFields.description,
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      select
                      label={t('generateMJOP.condition')}
                      value={inspectionState.condition}
                      onChange={(e) => handleFieldChange('condition', e.target.value)}
                      InputProps={{
                        readOnly: !editableFields.condition,
                      }}
                    >
                      <MenuItem value="">{t('generateMJOP.selectCondition')}</MenuItem>
                      <MenuItem value="1">1 = {t('generateMJOP.excellent')}</MenuItem>
                      <MenuItem value="2">2 = {t('generateMJOP.good')}</MenuItem>
                      <MenuItem value="3">3 = {t('generateMJOP.fair')}</MenuItem>
                      <MenuItem value="4">4 = {t('generateMJOP.moderate')}</MenuItem>
                      <MenuItem value="5">5 = {t('generateMJOP.poor')}</MenuItem>
                      <MenuItem value="6">6 = {t('generateMJOP.veryPoor')}</MenuItem>
                    </TextField>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      select
                      label={t('generateMJOP.urgency')}
                      value={inspectionState.urgency}
                      onChange={(e) => handleFieldChange('urgency', e.target.value)}
                      InputProps={{
                        readOnly: !editableFields.urgency,
                      }}
                    >
                      <MenuItem value="">{t('generateMJOP.selectUrgency')}</MenuItem>
                      <MenuItem value="1">1 = {t('generateMJOP.noUrgency')}</MenuItem>
                      <MenuItem value="2">2 = {t('generateMJOP.lowUrgency')}</MenuItem>
                      <MenuItem value="3">3 = {t('generateMJOP.mediumUrgency')}</MenuItem>
                      <MenuItem value="4">4 = {t('generateMJOP.highUrgency')}</MenuItem>
                      <MenuItem value="5">5 = {t('generateMJOP.veryHighUrgency')}</MenuItem>
                    </TextField>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      label={t('generateMJOP.elementType')}
                      value={inspectionState.elementType}
                      onChange={(e) => handleFieldChange('elementType', e.target.value)}
                      InputProps={{
                        readOnly: !editableFields.elementType,
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      label={t('generateMJOP.material')}
                      value={inspectionState.material}
                      onChange={(e) => handleFieldChange('material', e.target.value)}
                      InputProps={{
                        readOnly: !editableFields.material,
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      select
                      label={t('generateMJOP.damage')}
                      value={inspectionState.damage}
                      onChange={(e) => handleFieldChange('damage', e.target.value)}
                      InputProps={{
                        readOnly: !editableFields.damage,
                      }}
                    >
                      <MenuItem value="">{t('generateMJOP.selectDamage')}</MenuItem>
                      <MenuItem value="1">1 = {t('generateMJOP.noDamage')}</MenuItem>
                      <MenuItem value="2">2 = {t('generateMJOP.minorDamage')}</MenuItem>
                      <MenuItem value="3">3 = {t('generateMJOP.moderateDamage')}</MenuItem>
                      <MenuItem value="4">4 = {t('generateMJOP.severeDamage')}</MenuItem>
                      <MenuItem value="5">5 = {t('generateMJOP.criticalDamage')}</MenuItem>
                    </TextField>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      label={t('generateMJOP.elementFunction')}
                      value={inspectionState.elementFunction}
                      onChange={(e) => handleFieldChange('elementFunction', e.target.value)}
                      InputProps={{
                        readOnly: !editableFields.elementFunction,
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      type="number"
                      label={t('generateMJOP.surfaceArea')}
                      value={inspectionState.surfaceArea}
                      onChange={(e) => handleFieldChange('surfaceArea', e.target.value)}
                      InputProps={{
                        readOnly: !editableFields.surfaceArea,
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      select
                      label={t('generateMJOP.unit')}
                      value={inspectionState.unit}
                      onChange={(e) => handleFieldChange('unit', e.target.value)}
                      InputProps={{
                        readOnly: !editableFields.unit,
                      }}
                    >
                      <MenuItem value="">{t('generateMJOP.selectUnit')}</MenuItem>
                      <MenuItem value="m2">m²</MenuItem>
                      <MenuItem value="m3">m³</MenuItem>
                      <MenuItem value="st">st</MenuItem>
                    </TextField>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      type="date"
                      label={t('generateMJOP.inspectionDate')}
                      value={
                        inspectionState.inspectionDate
                          ? new Date(inspectionState.inspectionDate).toISOString().split('T')[0]
                          : ''
                      }
                      onChange={(e) => handleFieldChange('inspectionDate', e.target.value)}
                      InputProps={{
                        readOnly: !editableFields.inspectionDate,
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      type="number"
                      label={t('generateMJOP.estimatedPrice')}
                      value={inspectionState.estimatedPrice}
                      onChange={(e) => handleFieldChange('estimatedPrice', e.target.value)}
                      InputProps={{
                        readOnly: !editableFields.estimatedPrice,
                      }}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      multiline
                      label={t('generateMJOP.remarks')}
                      value={inspectionState.remarks}
                      onChange={(e) => handleFieldChange('remarks', e.target.value)}
                      InputProps={{
                        readOnly: !editableFields.remarks,
                      }}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <FormControl fullWidth>
                      <Button
                        variant="contained"
                        component="label"
                        startIcon={<AddPhotoAlternateIcon />}
                        sx={{ mb: 2 }}
                      >
                        {t('generateMJOP.uploadPhotos')}
                        <input
                          type="file"
                          hidden
                          multiple
                          accept="image/*"
                          onChange={(e) => handleAddImages(Array.from(e.target.files))}
                        />
                      </Button>
                      <Box display="flex" flexWrap="wrap" mt={2}>
                        {imagePreviews.map((src, index) => (
                          <Box key={index} position="relative" mr={2} mb={2}>
                            <img
                              src={src}
                              alt={`Inspection image ${index}`}
                              style={{
                                width: '100px',
                                height: '100px',
                                objectFit: 'contain',
                                borderRadius: 4,
                                boxShadow: 2,
                              }}
                            />
                            <Box display="flex" justifyContent="center" mt={1}>
                              <IconButton
                                size="small"
                                onClick={() => {
                                  const link = document.createElement('a');
                                  link.href = src;
                                  link.download = `image-${index}`;
                                  link.click();
                                }}
                              >
                                <DownloadIcon />
                              </IconButton>
                              <IconButton
                                size="small"
                                onClick={() => handleClearImage(index)}
                              >
                                <ClearIcon />
                              </IconButton>
                            </Box>
                          </Box>
                        ))}
                      </Box>
                    </FormControl>
                  </Grid>
                  <Grid item xs={12}>
                    <FormControl fullWidth>
                      <Button
                        variant="contained"
                        component="label"
                        startIcon={<InsertDriveFileIcon />}
                        sx={{ mb: 2 }}
                      >
                        {t('generateMJOP.uploadDocuments')}
                        <input
                          type="file"
                          hidden
                          multiple
                          accept=".pdf,.doc,.docx,.txt"
                          onChange={(e) => handleAddDocuments(Array.from(e.target.files))}
                        />
                      </Button>
                      <Box display="flex" flexWrap="wrap" mt={2}>
                        {documentPreviews.map((src, index) => {
                          const fileType = src.split('.').pop();
                          const icon = getFileIcon(fileType);
  
                          return (
                            <Box key={index} position="relative" mr={2} mb={2}>
                              <a href={src} download style={{ margin: '0 8px' }}>
                                {icon}
                              </a>
                              <Box display="flex" justifyContent="center" mt={1}>
                                <IconButton
                                  size="small"
                                  onClick={() => {
                                    const link = document.createElement('a');
                                    link.href = src;
                                    link.download = `document-${index}`;
                                    link.click();
                                  }}
                                >
                                  <DownloadIcon />
                                </IconButton>
                                <IconButton
                                  size="small"
                                  onClick={() => handleClearDocument(index)}
                                >
                                  <ClearIcon />
                                </IconButton>
                              </Box>
                            </Box>
                          );
                        })}
                      </Box>
                    </FormControl>
                  </Grid>
                </Grid>
              </Box>
            )}
            {tabIndex === 1 && (
              <Box display="flex" flexDirection="row" height="100%">
                <Box
                  sx={{
                    minWidth: '300px',
                    backgroundColor: '#f4f4f4',
                    borderRight: '1px solid #ddd',
                    overflowY: 'auto',
                    p: 2,
                  }}
                >
                  <Typography variant="h6" component="h3">
                    {t('generateMJOP.selectMistakes')}
                  </Typography>
                  <List sx={{ maxHeight: '70vh', overflowY: 'auto' }}>
                    <Typography variant="subtitle1" sx={{ mt: 2, fontWeight: 'bold' }}>
                      {t('generateMJOP.ernstig')}
                    </Typography>
                    {renderMistakeList('ernstig')}
                    <Typography variant="subtitle1" sx={{ mt: 2, fontWeight: 'bold' }}>
                      {t('generateMJOP.serieus')}
                    </Typography>
                    {renderMistakeList('serieus')}
                    <Typography variant="subtitle1" sx={{ mt: 2, fontWeight: 'bold' }}>
                      {t('generateMJOP.gering')}
                    </Typography>
                    {renderMistakeList('gering')}
                  </List>
                </Box>
                <Box p={4} flex={1}>
                  {mistakes.map((mistake, index) => (
                    <Grid container spacing={2} key={index} sx={{ mb: 2 }}>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          select
                          label={t('generateMJOP.mistakeCategory')}
                          value={mistake.category}
                          onChange={(e) => handleMistakeChange(index, 'category', e.target.value)}
                          fullWidth
                        >
                          {(gebreken.ernstig || [])
                            .concat(gebreken.serieus || [], gebreken.gering || [])
                            .map((category, i) => (
                              <MenuItem key={i} value={category}>
                                {category}
                              </MenuItem>
                            ))}
                        </TextField>
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          select
                          label={t('generateMJOP.severity')}
                          value={mistake.severity}
                          onChange={(e) => handleMistakeChange(index, 'severity', e.target.value)}
                          fullWidth
                        >
                          <MenuItem value="ernstig">{t('generateMJOP.ernstig')}</MenuItem>
                          <MenuItem value="serieus">{t('generateMJOP.serieus')}</MenuItem>
                          <MenuItem value="gering">{t('generateMJOP.gering')}</MenuItem>
                        </TextField>
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          type="number"
                          label={t('generateMJOP.extent')}
                          value={mistake.omvang}
                          onChange={(e) => handleMistakeChange(index, 'omvang', e.target.value)}
                          fullWidth
                          InputProps={{
                            inputProps: {
                              min: 0,
                              max: 100,
                            },
                          }}
                        />
                      </Grid>
                      <Grid item xs={12}>
                        <TextField
                          label={t('generateMJOP.description')}
                          value={mistake.description}
                          onChange={(e) => handleMistakeChange(index, 'description', e.target.value)}
                          fullWidth
                          multiline
                        />
                      </Grid>
                    </Grid>
                  ))}
                </Box>
              </Box>
            )}
            {tabIndex === 2 && (
              <Box p={4}>
                <Typography variant="h6" component="h3" mb={2}>
                  {t('generateMJOP.tasks')}
                </Typography>
                <Button variant="contained" color="primary" onClick={handleAddTask} sx={{ mb: 2 }}>
                  {t('generateMJOP.addTask')}
                </Button>
                {tasks.map((task) => (
                  <Paper key={task.id} sx={{ p: 2, mb: 2 }}>
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <TextField
                          fullWidth
                          label={t('generateMJOP.taskName')}
                          value={task.name}
                          onChange={(e) => handleTaskChange(task.id, 'name', e.target.value)}
                        />
                      </Grid>
                      <Grid item xs={12}>
                        <TextField
                          fullWidth
                          multiline
                          label={t('generateMJOP.taskDescription')}
                          value={task.description}
                          onChange={(e) => handleTaskChange(task.id, 'description', e.target.value)}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          fullWidth
                          type="number"
                          label={t('generateMJOP.estimatedPrice')}
                          value={task.estimatedPrice}
                          onChange={(e) => handleTaskChange(task.id, 'estimatedPrice', e.target.value)}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          fullWidth
                          label={t('generateMJOP.ultimateDate')}
                          type="date"
                          value={
                            task.ultimateDate
                              ? new Date(task.ultimateDate).toISOString().split('T')[0]
                              : ''
                          }
                          onChange={(e) => handleTaskChange(task.id, 'ultimateDate', e.target.value)}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          fullWidth
                          select
                          label={t('generateMJOP.urgency')}
                          value={task.urgency}
                          onChange={(e) => handleTaskChange(task.id, 'urgency', e.target.value)}
                        >
                          <MenuItem value="">{t('generateMJOP.selectUrgency')}</MenuItem>
                          <MenuItem value="1">1 = {t('generateMJOP.noUrgency')}</MenuItem>
                          <MenuItem value="2">2 = {t('generateMJOP.lowUrgency')}</MenuItem>
                          <MenuItem value="3">3 = {t('generateMJOP.mediumUrgency')}</MenuItem>
                          <MenuItem value="4">4 = {t('generateMJOP.highUrgency')}</MenuItem>
                          <MenuItem value="5">5 = {t('generateMJOP.veryHighUrgency')}</MenuItem>
                        </TextField>
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl fullWidth>
                          <Button
                            variant="contained"
                            component="label"
                            startIcon={<AddPhotoAlternateIcon />}
                            sx={{ mb: 2 }}
                          >
                            {t('generateMJOP.uploadPhoto')}
                            <input
                              type="file"
                              hidden
                              multiple
                              accept="image/*"
                              onChange={(e) => handleTaskImageChange(task.id, Array.from(e.target.files))}
                            />
                          </Button>
                          <Box display="flex" flexWrap="wrap" mt={2}>
                            {task.images &&
                              task.images.map((image, imageIndex) => (
                                <Box key={imageIndex} position="relative" mr={2} mb={2}>
                                  <IconButton
                                    size="small"
                                    onClick={() => handleTaskClearImage(task.id, imageIndex)}
                                    sx={{
                                      position: 'absolute',
                                      top: 4,
                                      right: 4,
                                      backgroundColor: 'rgba(255, 255, 255, 0.7)',
                                    }}
                                  >
                                    <ClearIcon />
                                  </IconButton>
                                  <img
                                    src={
                                      typeof image === 'string'
                                        ? `http://localhost:5000/${image}`
                                        : URL.createObjectURL(image)
                                    }
                                    alt={`Task image ${imageIndex}`}
                                    style={{
                                      width: '100px',
                                      height: '100px',
                                      objectFit: 'contain',
                                      borderRadius: 4,
                                      boxShadow: 2,
                                    }}
                                  />
                                  <Box display="flex" justifyContent="center" mt={1}>
                                    <IconButton
                                      size="small"
                                      onClick={() => {
                                        const link = document.createElement('a');
                                        link.href =
                                          typeof image === 'string'
                                            ? `http://localhost:5000/${image}`
                                            : URL.createObjectURL(image);
                                        link.download = `task-image-${task.id}-${imageIndex}`;
                                        link.click();
                                      }}
                                    >
                                      <DownloadIcon />
                                    </IconButton>
                                  </Box>
                                </Box>
                              ))}
                          </Box>
                        </FormControl>
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl fullWidth>
                          <Button
                            variant="contained"
                            component="label"
                            startIcon={<InsertDriveFileIcon />}
                            sx={{ mb: 2 }}
                          >
                            {t('generateMJOP.uploadDocuments')}
                            <input
                              type="file"
                              hidden
                              multiple
                              accept=".pdf,.doc,.docx,.txt"
                              onChange={(e) => handleTaskDocumentChange(task.id, Array.from(e.target.files))}
                            />
                          </Button>
                          <Box display="flex" flexWrap="wrap" mt={2}>
                            {task.documents &&
                              task.documents.map((doc, docIndex) => {
                                const fileType = doc.split('.').pop();
                                const icon = getFileIcon(fileType);
  
                                return (
                                  <Box key={docIndex} position="relative" mr={2} mb={2}>
                                    <IconButton
                                      size="small"
                                      onClick={() => handleTaskClearDocument(task.id, docIndex)}
                                      sx={{
                                        position: 'absolute',
                                        top: 4,
                                        right: 4,
                                        backgroundColor: 'rgba(255, 255, 255, 0.7)',
                                      }}
                                    >
                                      <ClearIcon />
                                    </IconButton>
                                    <a
                                      href={`http://localhost:5000/${doc}`}
                                      download
                                      style={{ margin: '0 8px' }}
                                    >
                                      {icon}
                                    </a>
                                    <Box display="flex" justifyContent="center" mt={1}>
                                      <IconButton
                                        size="small"
                                        onClick={() => {
                                          const link = document.createElement('a');
                                          link.href = `http://localhost:5000/${doc}`;
                                          link.download = doc.name;
                                          link.click();
                                        }}
                                      >
                                        <DownloadIcon />
                                      </IconButton>
                                    </Box>
                                  </Box>
                                );
                              })}
                          </Box>
                        </FormControl>
                      </Grid>
                      <Grid item xs={12} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                        <Button
                          variant="contained"
                          color="secondary"
                          startIcon={<Delete />}
                          onClick={() => handleDeleteTask(task.id)}
                        >
                          {t('generateMJOP.deleteTask')}
                        </Button>
                      </Grid>
                    </Grid>
                  </Paper>
                ))}
              </Box>
            )}
          </Box>
        </Box>
      </Paper>
    </Modal>
  );
  
  
  
  
  
};



const InspectionReport = ({
  globalElements,
  t,
  handleInspectionChange,
  handleDeleteInspection,
  handleRequestInspection,
  handleRequestInspectionForAll,
  filter,
  setFilter,
  setGlobalElements,
}) => {
  const [currentInspection, setCurrentInspection] = useState(null);
  const [currentElementId, setCurrentElementId] = useState(null);
  const [tasks, setTasks] = useState([]);

  const handleOpenModal = useCallback((elementId, inspection) => {
    setCurrentElementId(elementId);
    setCurrentInspection(inspection || { id: uuidv4(), tasks: [] });
    setTasks((inspection && inspection.tasks) || []);
  }, []);

  const handleCloseModal = useCallback(() => {
    setGlobalElements((prevElements) =>
      prevElements.map((element) =>
        element.id === currentElementId
          ? {
              ...element,
              inspectionReport: element.inspectionReport.map((report) =>
                report.id === currentInspection.id
                  ? { ...report, tasks }
                  : report
              ),
            }
          : element
      )
    );
    setCurrentElementId(null);
    setCurrentInspection(null);
    setTasks([]);
  }, [currentElementId, currentInspection, tasks, setGlobalElements]);

  const handleTaskChange = useCallback(
    (taskId, field, value) => {
      setTasks((prevTasks) =>
        prevTasks.map((task) =>
          task.id === taskId ? { ...task, [field]: value } : task
        )
      );
    },
    []
  );

  const handleAddTask = useCallback(() => {
    const newTask = { id: uuidv4(), name: '', description: '', estimatedPrice: '', images: [], documents: [], ultimateDate: '', urgency: '' };
    setTasks((prevTasks) => [...prevTasks, newTask]);
  }, []);

  const handleDeleteTask = useCallback((taskId) => {
    setTasks((prevTasks) => prevTasks.filter((task) => task.id !== taskId));
  }, []);

  const handleTaskImageChange = useCallback((taskId, files) => {
    const formData = new FormData();
    files.forEach((file) => {
      formData.append('file', file);
    });

    axios
      .post('http://localhost:5000/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      .then(({ data }) => {
        setTasks((prevTasks) =>
          prevTasks.map((task) =>
            task.id === taskId
              ? { ...task, images: [...(task.images || []), data.filePath] }
              : task
          )
        );
      });
  }, []);

  const handleTaskDocumentChange = useCallback((taskId, files) => {
    const formData = new FormData();
    files.forEach((file) => {
      formData.append('file', file);
    });

    axios
      .post('http://localhost:5000/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      .then(({ data }) => {
        setTasks((prevTasks) =>
          prevTasks.map((task) =>
            task.id === taskId
              ? { ...task, documents: [...(task.documents || []), data.filePath] }
              : task
          )
        );
      });
  }, []);

  const handleInspectionDoneChange = useCallback((elementId, inspectionId, checked) => {
    setGlobalElements((prevElements) =>
      prevElements.map((element) => {
        if (element.id === elementId) {
          const updatedInspectionReport = element.inspectionReport.map((inspection) => {
            if (inspection.id === inspectionId) {
              return {
                ...inspection,
                inspectionDone: checked,
                inspectionDoneDate: checked ? new Date().toISOString() : null,
              };
            }
            return inspection;
          });

          // Schedule a new inspection if the inspection is done
          const intervalMonths = parseInt(element.interval || 6, 10); // Default to 6 months if no interval is set
          const newInspectionDate = checked
            ? new Date(new Date().setMonth(new Date().getMonth() + intervalMonths)).toISOString()
            : null;

          if (checked) {
            updatedInspectionReport.push({
              id: uuidv4(),
              element: element.name,
              description: element.description,
              condition: '',
              surfaceArea: '',
              unit: '',
              year: '',
              month: '',
              estimatedPrice: '',
              werkzaamheden: '',
              inspectionDate: newInspectionDate,
              inspectionDone: false,
              inspectionDoneDate: null,
              images: [],
              documents: [],
              tasks: []
            });
          }

          return { ...element, inspectionReport: updatedInspectionReport };
        }
        return element;
      })
    );
  }, [setGlobalElements]);

  return (
    <Box>
      <InspectionTable
        handleOpenModal={(elementId, inspection) => handleOpenModal(elementId, inspection || { id: uuidv4(), tasks: [] })}
        handleInspectionChange={handleInspectionChange}
        handleDeleteInspection={handleDeleteInspection}
        handleInspectionDoneChange={handleInspectionDoneChange}
        handleRequestInspection={handleRequestInspection}
        handleRequestInspectionForAll={handleRequestInspectionForAll}
        items={globalElements}
        filter={filter}
        setFilter={setFilter}
        t={t}
      />
      <InspectionModal
        currentElementId={currentElementId}
        currentInspection={currentInspection}
        handleCloseModal={handleCloseModal}
        handleInspectionChange={handleInspectionChange}
        t={t}
        tasks={tasks}
        handleTaskChange={handleTaskChange}
        handleAddTask={handleAddTask}
        handleDeleteTask={handleDeleteTask}
        handleTaskDocumentChange={handleTaskDocumentChange}
        handleTaskImageChange={handleTaskImageChange}
        editableFields={{
          name: true,
          description: true,
          condition: true,
          urgency: true,
          elementType: true,
          damage: true,
          elementFunction: true,
          surfaceArea: true,
          unit: true,
          inspectionDate: true,
          estimatedPrice: true,
          remarks: true,
        }}
        globalElements={globalElements}
      />
    </Box>
  );
};

export default InspectionReport;
