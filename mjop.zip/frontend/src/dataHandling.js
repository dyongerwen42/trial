import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';

export const fetchMJOPData = async (
  id,
  setMJOP,
  setGeneralInfo,
  setCashInfo,
  setGroups,
  setTotalWorth,
  setGlobalElements,
  setGlobalSpaces,
  setInspectionReports,
  setGlobalDocuments
) => {
  try {
    const response = await axios.get(`http://localhost:5000/mjop/${id}`, { withCredentials: true });
    const data = response.data;
    setMJOP(data.mjop);
    setGeneralInfo(data.generalInfo);
    setCashInfo(data.cashInfo);
    setGroups(data.groups ? data.groups.map(group => ({
      ...group,
      items: group.items.map(item => ({ ...item, id: uuidv4() }))
    })) : []);
    setTotalWorth(data.totalWorth || 0);
    setGlobalElements(data.globalElements || []);
    setGlobalSpaces(data.globalSpaces || []);
    setInspectionReports(Array.isArray(data.inspectionReports) ? data.inspectionReports : []); // Ensure it's an array
    setGlobalDocuments(data.globalDocuments || []);
  } catch (err) {
    console.error(`[${new Date().toISOString()}] Error fetching MJOP:`, err);
  }
};

export const saveMJOPData = async (id, formData, config, setIsSaving, setSuccess, setErrors, navigate, t) => {
  try {
    console.log(`[${new Date().toISOString()}] Preparing to save MJOP data. ID: ${id}`);

    // Ensure inspectionReports is an array
    if (!Array.isArray(formData.inspectionReports)) {
      console.error(`[${new Date().toISOString()}] Invalid inspectionReports data type`);
      throw new Error('inspectionReports is not an array');
    }

    // Stringify the data
    const payload = {
      mjop: JSON.stringify(formData.mjop),
      generalInfo: JSON.stringify(formData.generalInfo),
      cashInfo: JSON.stringify(formData.cashInfo),
      globalElements: JSON.stringify(formData.globalElements),
      globalSpaces: JSON.stringify(formData.globalSpaces),
      globalDocuments: JSON.stringify(formData.globalDocuments),
      inspectionReports: JSON.stringify(formData.inspectionReports),
    };

    if (id) {
      console.log(`[${new Date().toISOString()}] Updating existing MJOP with ID: ${id}`);
      await axios.put(`http://localhost:5000/mjop/${id}`, payload, config);
      setSuccess(t('generateMJOP.updated'));
    } else {
      console.log(`[${new Date().toISOString()}] Creating new MJOP`);
      const response = await axios.post('http://localhost:5000/save-mjop', payload, config);
      const newId = response.data.id;
      setSuccess(t('generateMJOP.saved'));
      navigate(`/mjop/${newId}`);
    }

    setIsSaving(false);
  } catch (err) {
    console.error(`[${new Date().toISOString()}] Error saving MJOP data:`, err);
    setIsSaving(false);
    setErrors({ general: t('generateMJOP.error') });
  }
};


export const calculateCurrentCash = (cashInfo, globalElements) => {
  let remainingCash = parseFloat(cashInfo.currentCash);
  const monthlyContribution = parseFloat(cashInfo.monthlyContribution);
  const reserveStartDate = new Date(cashInfo.reserveDate);

  const tasks = globalElements.flatMap(element =>
    element.inspectionReport.flatMap(report => report.tasks)
  );

  tasks.sort((a, b) => new Date(a.planned?.workDate || a.ultimateDate) - new Date(b.planned?.workDate || b.ultimateDate)).forEach((task) => {
    const taskDate = new Date(task.planned?.workDate || task.ultimateDate);
    const monthsDifference = (taskDate.getFullYear() - reserveStartDate.getFullYear()) * 12 + (taskDate.getMonth() - reserveStartDate.getMonth());
    const totalContribution = monthsDifference * monthlyContribution;

    let taskCost = 0;
    if (task.planned?.invoicePrice) {
      taskCost = parseFloat(task.planned.invoicePrice);
    } else if (task.planned?.offerPrice) {
      taskCost = parseFloat(task.planned.offerPrice);
    } else if (task.planned?.estimatedPrice) {
      taskCost = parseFloat(task.planned.estimatedPrice);
    }

    remainingCash += totalContribution - taskCost;
  });

  return remainingCash;
};



export const getSaldoColor = (currentCash, totalWorth) => {
  const minimumRequired = parseFloat(totalWorth) * 0.005;
  if (currentCash < 0) return 'bg-red-500';
  if (currentCash < minimumRequired) return 'bg-orange-500';
  return 'bg-green-500';
};
