import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useTable } from 'react-table';
import {
  Box,
  Button,
  Container,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableSortLabel,
  IconButton,
} from '@mui/material';
import { Edit, Visibility } from '@mui/icons-material';

const MJOPList = () => {
  const [mjops, setMJOPs] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchMJOPs = async () => {
      try {
        const response = await axios.get('http://localhost:5000/mjops', { withCredentials: true });
        setMJOPs(response.data);
      } catch (err) {
        console.error('Error fetching MJOPs', err);
      }
    };

    fetchMJOPs();
  }, []);

  const columns = useMemo(() => [
    {
      Header: 'Project Name',
      accessor: 'generalInfo.projectName',
    },
    {
      Header: 'Address',
      accessor: 'generalInfo.address',
    },
    {
      Header: 'Contact Person',
      accessor: 'generalInfo.contactPerson',
    },
    {
      Header: 'Actions',
      Cell: ({ row }) => (
        <Box>
          <IconButton
            onClick={() => navigate(`/view-mjop/${row.original._id}`)}
            color="primary"
          >
            <Visibility />
          </IconButton>
          <IconButton
            onClick={() => navigate(`/edit-mjop/${row.original._id}`)}
            color="secondary"
          >
            <Edit />
          </IconButton>
        </Box>
      ),
    },
  ], [navigate]);

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = useTable({ columns, data: mjops });

  return (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        MJOP List
      </Typography>
      <TableContainer component={Paper}>
        <Table {...getTableProps()} aria-label="MJOP table">
          <TableHead>
            {headerGroups.map(headerGroup => (
              <TableRow key={headerGroup.id} {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map(column => (
                  <TableCell key={column.id} {...column.getHeaderProps()}>
                    <TableSortLabel>
                      {column.render('Header')}
                    </TableSortLabel>
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableHead>
          <TableBody {...getTableBodyProps()}>
            {rows.map(row => {
              prepareRow(row);
              return (
                <TableRow key={row.id} {...row.getRowProps()}>
                  {row.cells.map(cell => (
                    <TableCell key={cell.id} {...cell.getCellProps()}>
                      {cell.render('Cell')}
                    </TableCell>
                  ))}
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </Container>
  );
};

export default MJOPList;
