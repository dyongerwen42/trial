const validate = ({ generalInfo, cashInfo, totalWorth, globalElements, t }) => {
  const newErrors = {};
  const newTabErrors = {
    generalInfo: false,
    cashInfo: false,
    globalSpaces: false,
    globalElements: false,
    inspectionReport: false,
    planning: false,
    globalDocuments: false,
  };

  if (!generalInfo.projectNumber) {
    newErrors.projectNumber = t('generateMJOP.projectNumberRequired');
    newTabErrors.generalInfo = true;
  }
  if (!generalInfo.projectName) {
    newErrors.projectName = t('generateMJOP.projectNameRequired');
    newTabErrors.generalInfo = true;
  }
  if (!cashInfo.currentCash) {
    newErrors.currentCash = t('generateMJOP.currentCashRequired');
    newTabErrors.cashInfo = true;
  }
  if (!cashInfo.monthlyContribution) {
    newErrors.monthlyContribution = t('generateMJOP.monthlyContributionRequired');
    newTabErrors.cashInfo = true;
  }
  if (!cashInfo.reserveDate) {
    newErrors.reserveDate = t('generateMJOP.reserveDateRequired');
    newTabErrors.cashInfo = true;
  }
  if (!totalWorth) {
    newErrors.totalWorth = t('generateMJOP.totalWorthRequired');
    newTabErrors.cashInfo = true;
  }

  globalElements.forEach((element, elementIndex) => {
    if (!element.name) {
      if (!newErrors.elements) newErrors.elements = [];
      newErrors.elements[elementIndex] = { name: t('generateMJOP.elementNameRequired') };
      newTabErrors.globalElements = true;
    }
  });

  const isValid = Object.keys(newErrors).length === 0;
  return { newErrors, newTabErrors, isValid };
};

export default validate;
