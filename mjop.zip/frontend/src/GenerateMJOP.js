import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Box, Button, Tabs, Tab, Typography, Badge, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import { useTranslation } from 'react-i18next';
import { useParams, useNavigate } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';
import axios from 'axios';
import produce from 'immer';

import GeneralInfo from './GeneralInfo';
import CashInfo from './CashInfo';
import GlobalSpaces from './GlobalSpaces';
import GlobalElements from './GlobalElements';
import Planning from './Planning';
import GlobalDocuments from './GlobalDocuments';
import InspectionReport from './InspectionReport';
import elementsData from './inspectionTasks.json';
import spacesData from './spaces.json';
import validate from './validation';
import { fetchMJOPData, saveMJOPData, calculateCurrentCash, getSaldoColor } from './dataHandling';

const GenerateMJOP = () => {
  const { t } = useTranslation();
  const { id } = useParams();
  const navigate = useNavigate();
  const [value, setValue] = useState(0);

  const [generalInfo, setGeneralInfo] = useState({
    projectNumber: '',
    projectName: '',
    address: '',
    contactPerson: '',
    inspectionDate: '',
    propertyImage: null,
    opdrachtgeverNaam: '',
    opdrachtgeverAdres: '',
    opdrachtgeverPostcode: '',
    opdrachtgeverPlaats: '',
    opdrachtgeverTelefoon: '',
    opdrachtgeverEmail: '',
    inspecteur: '',
    inspectiedatum: '',
    opmerkingen: '',
  });

  const [cashInfo, setCashInfo] = useState({
    currentCash: '',
    monthlyContribution: '',
    reserveDate: '',
    totalWorth: '',
  });

  const [mjop, setMJOP] = useState({});
  const [globalElements, setGlobalElements] = useState([]);
  const [globalSpaces, setGlobalSpaces] = useState([]);
  const [globalDocuments, setGlobalDocuments] = useState([]);
  const [inspectionReports, setInspectionReports] = useState([]);
  const [isSaving, setIsSaving] = useState(false);
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState(null);
  const [newElement, setNewElement] = useState({
    name: '',
    description: '',
    inspectionDate: null,
    interval: '',
    documents: [],
    photos: [],
    spaceId: '',
  });
  const [newSpace, setNewSpace] = useState({
    name: '',
    description: '',
    photos: [],
  });
  const [filter, setFilter] = useState('todo');
  const [tabErrors, setTabErrors] = useState({
    generalInfo: false,
    cashInfo: false,
    globalSpaces: false,
    globalElements: false,
    inspectionReport: false,
    planning: false,
    globalDocuments: false,
  });
  const [openErrorDialog, setOpenErrorDialog] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const logAction = useCallback((action, data) => {
    console.log(`[${new Date().toISOString()}] ${action}:`, JSON.stringify(data, null, 2));
  }, []);

  useEffect(() => {
    if (id) {
      fetchMJOPData(
        id,
        setMJOP,
        setGeneralInfo,
        setCashInfo,
        () => {}, // Placeholder for setGroups
        () => {}, // Placeholder for setTotalWorth
        setGlobalElements,
        setGlobalSpaces,
        setInspectionReports,
        setGlobalDocuments
      );
    } else {
      setGlobalElements([]);
      setGlobalSpaces([]);
      setInspectionReports([]); // Initialize as an empty array
    }
    logAction('Initial load', { id, generalInfo, globalElements, globalSpaces, globalDocuments });
  }, [id, logAction]);

  const initializeInspectionReports = useCallback((elements) => {
    if (!Array.isArray(elements)) {
      console.error("initializeInspectionReports expected an array but got:", elements);
      return [];
    }

    return elements.map((element) => {
      if (!element.inspectionReport || element.inspectionReport.length === 0) {
        return {
          ...element,
          inspectionReport: [
            {
              id: uuidv4(),
              element: element.name,
              description: '',
              condition: '',
              surfaceArea: '',
              unit: '',
              year: '',
              month: '',
              estimatedPrice: '',
              werkzaamheden: '',
              inspectionDate: new Date().toISOString().split('T')[0],
              inspectionDone: false,
              inspectionDoneDate: null,
              images: [],
              documents: [],
              tasks: [],
            },
          ],
        };
      }
      return element;
    });
  }, []);

  const handleChange = useCallback((section, field, value) => {
    logAction('Handle change', { section, field, value });
    if (section === 'cashInfo') {
      setCashInfo((prev) => ({
        ...prev,
        [field]: value,
      }));
    } else if (section === 'generalInfo') {
      setGeneralInfo((prev) => ({
        ...prev,
        [field]: value,
      }));
    } else {
      setGlobalElements((prev) =>
        prev.map((element) =>
          element.id === section
            ? { ...element, [field]: value }
            : element
        )
      );
    }
  }, [logAction]);

  const handleValidation = useCallback(() => {
    const { newErrors, newTabErrors, isValid } = validate({ generalInfo, cashInfo, totalWorth: cashInfo.totalWorth, globalElements, t });
    setErrors(newErrors);
    setTabErrors(newTabErrors);
    logAction('Handle validation', { newErrors, newTabErrors, isValid });
    return isValid;
  }, [generalInfo, cashInfo, globalElements, t, logAction]);

  const handleSubmit = useCallback(async (e) => {
    e.preventDefault();
    setIsSaving(true);
    setErrors({});
    setSuccess(null);

    if (!handleValidation()) {
      setIsSaving(false);
      setErrors((prevErrors) => ({ ...prevErrors, general: t('generateMJOP.fixValidationErrors') }));
      return;
    }

    try {
      const data = {
        mjop,
        generalInfo,
        cashInfo,
        globalElements,
        globalSpaces,
        globalDocuments,
        inspectionReports,
      };

      const config = {
        headers: {
          'Content-Type': 'application/json',
        },
        withCredentials: true,
      };

      await saveMJOPData(id, data, config, setIsSaving, setSuccess, setErrors, navigate, t);
    } catch (err) {
      console.error(`[${new Date().toISOString()}] Error saving MJOP data:`, err);
      setIsSaving(false);
      setErrors({ general: t('generateMJOP.error') });
    }
  }, [id, handleValidation, mjop, generalInfo, cashInfo, globalElements, globalSpaces, globalDocuments, inspectionReports, t, navigate]);

  const handleInspectionChange = useCallback((elementId, inspectionId, field, value) => {
    logAction('Handle inspection change', { elementId, inspectionId, field, value });
    setGlobalElements((prevElements) =>
      prevElements.map((element) =>
        element.id === elementId
          ? {
              ...element,
              inspectionReport: element.inspectionReport?.length
                ? element.inspectionReport.map((inspection) =>
                    inspection.id === inspectionId
                      ? { ...inspection, [field]: value }
                      : inspection
                  )
                : [],
            }
          : element
      )
    );
  }, [logAction]);

  const handleInspectionDoneChange = useCallback(
    (elementId, inspectionId, checked) => {
      logAction('Handle inspection done change', { elementId, inspectionId, checked });
      setGlobalElements((prevElements) =>
        prevElements.map((element) => {
          if (element.id === elementId) {
            const updatedInspectionReport = element.inspectionReport.map(
              (inspection) => {
                if (inspection.id === inspectionId) {
                  return {
                    ...inspection,
                    inspectionDone: checked,
                    inspectionDoneDate: checked ? new Date().toISOString() : null,
                  };
                }
                return inspection;
              }
            );

            const intervalMonths = parseInt(element.interval || 6, 10);
            const newInspectionDate = checked
              ? new Date(new Date().setMonth(new Date().getMonth() + intervalMonths)).toISOString()
              : null;

            if (checked) {
              updatedInspectionReport.push({
                id: uuidv4(),
                element: element.name,
                description: element.description,
                condition: '',
                surfaceArea: '',
                unit: '',
                year: '',
                month: '',
                estimatedPrice: '',
                werkzaamheden: '',
                inspectionDate: newInspectionDate,
                inspectionDone: false,
                inspectionDoneDate: null,
                images: [],
                documents: [],
              });
            }

            return { ...element, inspectionReport: updatedInspectionReport };
          }
          return element;
        })
      );
    },
    [logAction]
  );

  const handleRequestInspection = useCallback((elementId, inspectionId) => {
    logAction('Handle request inspection', { elementId, inspectionId });
    setGlobalElements((prevElements) =>
      prevElements.map((element) =>
        element.id === elementId
          ? {
              ...element,
              inspectionReport: element.inspectionReport.map((inspection) =>
                inspection.id === inspectionId
                  ? { ...inspection, inspectionDone: true, inspectionDoneDate: new Date() }
                  : inspection
              ),
            }
          : element
      )
    );
  }, [logAction]);

  const handleRequestInspectionForAll = useCallback(() => {
    logAction('Handle request inspection for all', {});
    setGlobalElements((prevElements) =>
      prevElements.map((element) => ({
        ...element,
        inspectionReport: element.inspectionReport.map((inspection) => ({
          ...inspection,
          inspectionDone: true,
          inspectionDoneDate: new Date(),
        })),
      }))
    );
  }, [logAction]);

  const handleAddElement = useCallback((element) => {
    const elementWithId = { ...element, id: uuidv4() };
    logAction('Handle add element', { elementWithId });
    setGlobalElements((prev) => [...prev, elementWithId]);
  }, [logAction]);

  const handleEditElement = useCallback((element) => {
    logAction('Handle edit element', { element });
    setGlobalElements((prev) =>
      prev.map((el) => (el.id === element.id ? element : el))
    );
  }, [logAction]);

  const handleDeleteElement = useCallback((id) => {
    logAction('Handle delete element', { id });
    setGlobalElements((prev) =>
      prev.filter((element) => element.id !== id)
    );
  }, [logAction]);

  const handleAddSpace = useCallback((space) => {
    const spaceWithId = { ...space, id: uuidv4() };
    logAction('Handle add space', { spaceWithId });
    setGlobalSpaces((prev) => [...prev, spaceWithId]);
  }, [logAction]);

  const handleEditSpace = useCallback((space) => {
    logAction('Handle edit space', { space });
    setGlobalSpaces((prev) =>
      prev.map((sp) => (sp.id === space.id ? space : sp))
    );
  }, [logAction]);

  const handleDeleteSpace = useCallback((id) => {
    logAction('Handle delete space', { id });
    setGlobalSpaces((prev) =>
      prev.filter((space) => space.id !== id)
    );
  }, [logAction]);

  const handleAddItemToPlanning = useCallback((task, elementId) => {
    logAction('Add item to planning', { task, elementId });
    setGlobalElements((prev) =>
      produce(prev, (draft) => {
        const element = draft.find((el) => el.id === elementId);
        if (element) {
          const inspection = element.inspectionReport.find((ir) =>
            ir.tasks.some((t) => t.id === task.id)
          );
          if (inspection) {
            const taskToUpdate = inspection.tasks.find((t) => t.id === task.id);
            if (taskToUpdate) {
              taskToUpdate.planned = true;
              taskToUpdate.plannedData = {
                workDate: task.workDate,
                estimatedPrice: task.estimatedPrice,
                comment: task.comment,
                files: task.files || [],
              };
            }
          }
        }
      })
    );
  }, [logAction]);

  const handleItemChange = useCallback((taskId, field, value) => {
    logAction('Handle item change', { taskId, field, value });
    setGlobalElements((prev) =>
      produce(prev, (draft) => {
        draft.forEach((element) => {
          element.inspectionReport.forEach((report) => {
            const task = report.tasks.find((t) => t.id === taskId);
            if (task) {
              task.plannedData = {
                ...task.plannedData,
                [field]: value,
              };
            }
          });
        });
      })
    );
  }, [logAction]);

  const handleDeleteItem = useCallback((taskId) => {
    logAction('Handle delete item', { taskId });
    setGlobalElements((prev) =>
      produce(prev, (draft) => {
        draft.forEach((element) => {
          element.inspectionReport.forEach((report) => {
            const task = report.tasks.find((t) => t.id === taskId);
            if (task) {
              task.planned = false;
              task.plannedData = {};
            }
          });
        });
      })
    );
  }, [logAction]);

  const handleAddCustomItem = useCallback((item) => {
    logAction('Handle add custom item', { item });
    setGlobalElements((prev) =>
      produce(prev, (draft) => {
        const generalElement = draft.find((el) => el.name === 'Algemeneen');
        if (generalElement) {
          const inspection = generalElement.inspectionReport[0];
          inspection.tasks.push({
            ...item,
            id: uuidv4(),
            planned: true,
            plannedData: {
              workDate: item.workDate,
              estimatedPrice: item.estimatedPrice,
              comment: item.comment,
              files: item.files || [],
            },
          });
        } else {
          draft.push({
            id: uuidv4(),
            name: 'Algemeneen',
            description: '',
            inspectionReport: [
              {
                id: uuidv4(),
                element: 'Algemeneen',
                description: '',
                tasks: [
                  {
                    ...item,
                    id: uuidv4(),
                    planned: true,
                    plannedData: {
                      workDate: item.workDate,
                      estimatedPrice: item.estimatedPrice,
                      comment: item.comment,
                      files: item.files || [],
                    },
                  },
                ],
              },
            ],
          });
        }
      })
    );
  }, [logAction]);

  const handleTabChange = useCallback((event, newValue) => {
    const checkCashFields = () => {
      const { currentCash, monthlyContribution, reserveDate, totalWorth } = cashInfo;
      return currentCash && monthlyContribution && reserveDate && totalWorth;
    };

    if (newValue === 5 && !checkCashFields()) {
      setErrorMessage(t('generateMJOP.fillCashFieldsError'));
      setOpenErrorDialog(true);
      return;
    }

    if (newValue === 3 && globalSpaces.length === 0) {
      setErrorMessage(t('generateMJOP.defineSpacesError'));
      setOpenErrorDialog(true);
      return;
    }

    if (newValue === 4 && globalElements.length === 0) {
      setErrorMessage(t('generateMJOP.defineElementsError'));
      setOpenErrorDialog(true);
      return;
    }

    setValue(newValue);
  }, [cashInfo, globalSpaces.length, globalElements.length, t]);

  const memoizedGeneralInfo = useMemo(() => (
    <GeneralInfo
      generalInfo={generalInfo}
      setGeneralInfo={setGeneralInfo}
      errors={errors}
      t={t}
    />
  ), [generalInfo, errors, t]);

  const memoizedCashInfo = useMemo(() => (
    <CashInfo
      cashInfo={cashInfo}
      setCashInfo={setCashInfo}
      errors={errors}
      calculateCurrentCash={() => calculateCurrentCash(cashInfo, globalElements)}
      getSaldoColor={() => getSaldoColor(calculateCurrentCash(cashInfo, globalElements), cashInfo.totalWorth)}
      t={t}
    />
  ), [cashInfo, errors, globalElements, t]);

  const memoizedGlobalSpaces = useMemo(() => (
    <GlobalSpaces
      availableSpaces={spacesData}
      globalSpaces={globalSpaces}
      setGlobalSpaces={setGlobalSpaces}
      newSpace={newSpace}
      setNewSpace={setNewSpace}
      handleAddSpace={handleAddSpace}
      handleEditSpace={handleEditSpace}
      handleDeleteSpace={handleDeleteSpace}
      t={t}
    />
  ), [globalSpaces, newSpace, handleAddSpace, handleEditSpace, handleDeleteSpace, t]);

  const memoizedGlobalElements = useMemo(() => (
    <GlobalElements
      availableElements={elementsData}
      globalElements={globalElements}
      setGlobalElements={setGlobalElements}
      newElement={newElement}
      setNewElement={setNewElement}
      globalSpaces={globalSpaces}
      handleAddElement={handleAddElement}
      handleEditElement={handleEditElement}
      handleDeleteElement={handleDeleteElement}
      t={t}
    />
  ), [globalElements, newElement, globalSpaces, handleAddElement, handleEditElement, handleDeleteElement, t]);

  const memoizedInspectionReport = useMemo(() => (
    <InspectionReport
      globalElements={initializeInspectionReports(globalElements)}
      t={t}
      handleInspectionChange={handleInspectionChange}
      handleInspectionDoneChange={handleInspectionDoneChange}
      handleRequestInspection={handleRequestInspection}
      handleRequestInspectionForAll={handleRequestInspectionForAll}
      filter={filter}
      setFilter={setFilter}
      setGlobalElements={setGlobalElements}
    />
  ), [globalElements, initializeInspectionReports, t, handleInspectionChange, handleInspectionDoneChange, handleRequestInspection, handleRequestInspectionForAll, filter]);

  const memoizedPlanning = useMemo(() => (
    <Planning
      globalSpaces={globalSpaces}
      globalElements={globalElements}
      setGlobalElements={setGlobalElements}
      handleAddItem={handleAddItemToPlanning}
      handleItemChange={handleItemChange}
      handleDeleteItem={handleDeleteItem}
      handleAddCustomItem={handleAddCustomItem}
      cashInfo={cashInfo}
      t={t}
    />
  ), [globalSpaces, globalElements, handleAddItemToPlanning, handleItemChange, handleDeleteItem, handleAddCustomItem, cashInfo, t]);

  const memoizedGlobalDocuments = useMemo(() => (
    <GlobalDocuments
      globalDocuments={globalDocuments}
      setGlobalDocuments={setGlobalDocuments}
      t={t}
    />
  ), [globalDocuments, t]);

  return (
    <Box mx="auto" p={4}>
      <Box component="form" onSubmit={handleSubmit} sx={{ bgcolor: 'background.paper', p: 3, borderRadius: 1, boxShadow: 2 }}>
        <Tabs value={value} onChange={handleTabChange}>
          <Tab
            label={
              <Badge
                color="error"
                variant="dot"
                invisible={!tabErrors.generalInfo}
              >
                {t('generateMJOP.generalInfo')}
              </Badge>
            }
          />
          <Tab
            label={
              <Badge
                color="error"
                variant="dot"
                invisible={!tabErrors.cashInfo}
              >
                {t('generateMJOP.cashInfo')}
              </Badge>
            }
          />
          <Tab
            label={
              <Badge
                color="error"
                variant="dot"
                invisible={!tabErrors.globalSpaces}
              >
                {t('generateMJOP.globalSpaces')}
              </Badge>
            }
          />
          <Tab
            label={
              <Badge
                color="error"
                variant="dot"
                invisible={!tabErrors.globalElements}
              >
                {t('generateMJOP.globalElements')}
              </Badge>
            }
          />
          <Tab
            label={
              <Badge
                color="error"
                variant="dot"
                invisible={!tabErrors.inspectionReport}
              >
                {t('generateMJOP.inspectionReport')}
              </Badge>
            }
          />
          <Tab
            label={
              <Badge
                color="error"
                variant="dot"
                invisible={!tabErrors.planning}
              >
                {t('generateMJOP.planning')}
              </Badge>
            }
          />
          <Tab
            label={
              <Badge
                color="error"
                variant="dot"
                invisible={!tabErrors.globalDocuments}
              >
                {t('generateMJOP.globalDocuments')}
              </Badge>
            }
          />
        </Tabs>
        <TabPanel value={value} index={0}>
          {memoizedGeneralInfo}
        </TabPanel>
        <TabPanel value={value} index={1}>
          {memoizedCashInfo}
        </TabPanel>
        <TabPanel value={value} index={2}>
          {memoizedGlobalSpaces}
        </TabPanel>
        <TabPanel value={value} index={3}>
          {memoizedGlobalElements}
        </TabPanel>
        <TabPanel value={value} index={4}>
          {memoizedInspectionReport}
        </TabPanel>
        <TabPanel value={value} index={5}>
          {memoizedPlanning}
        </TabPanel>
        <TabPanel value={value} index={6}>
          {memoizedGlobalDocuments}
        </TabPanel>

        <Button
          type="submit"
          variant="contained"
          color="primary"
          fullWidth
          sx={{ mt: 2 }}
          disabled={isSaving}
        >
          {isSaving ? t('generateMJOP.saving') : t('generateMJOP.saveMJOP')}
        </Button>
        {errors.general && <Typography color="error" mt={2}>
          {errors.general}</Typography>}
        {success && <Typography color="success" mt={2}>{success}</Typography>}
      </Box>
      <Dialog
        open={openErrorDialog}
        onClose={() => setOpenErrorDialog(false)}
      >
        <DialogTitle>{t('generateMJOP.error')}</DialogTitle>
        <DialogContent>
          <Typography>{errorMessage}</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenErrorDialog(false)} color="primary">
            {t('generateMJOP.ok')}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

const TabPanel = (props) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};

export default GenerateMJOP;
