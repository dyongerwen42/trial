import React, { useState } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Modal,
  Backdrop,
  Fade,
  Button,
  IconButton,
  Divider,
  Tooltip,
} from '@mui/material';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import ImageIcon from '@mui/icons-material/Image';
import CloseIcon from '@mui/icons-material/Close';

const Spaces = ({ globalSpaces }) => {
  const [open, setOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState('');

  const handleOpen = (file) => {
    setSelectedFile(file);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setSelectedFile('');
  };

  return (
    <Box sx={{ p: 4, bgcolor: '#f5f5f5', borderRadius: 2 }}>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold', mb: 3, color: '#333' }}>
        Ruimtes
      </Typography>
      {globalSpaces.map((space) => (
        <Card elevation={3} sx={{ mb: 3, borderRadius: 2 }} key={space.id}>
          <CardContent>
            <Typography variant="h5" sx={{ fontWeight: 'bold', mb: 2 }}>
              {space.name}
            </Typography>
            <Typography variant="body1" color="textSecondary" sx={{ mb: 3 }}>
              {space.description}
            </Typography>
            {space.photos && space.photos.length > 0 && (
              <>
                <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: 2 }}>
                  Foto's
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                  {space.photos.map((photo, index) => (
                    <Tooltip title={`Foto ${index + 1}`} key={index}>
                      <Box
                        onClick={() => handleOpen(`http://localhost:5000/${photo}`)}
                        sx={{
                          display: 'flex',
                          alignItems: 'center',
                          cursor: 'pointer',
                          color: '#1976d2',
                          '&:hover': {
                            textDecoration: 'underline',
                          },
                        }}
                      >
                        <ImageIcon sx={{ mr: 1 }} />
                        <Typography>Foto {index + 1}</Typography>
                      </Box>
                    </Tooltip>
                  ))}
                </Box>
              </>
            )}
            {space.documents && space.documents.length > 0 && (
              <>
                <Divider sx={{ my: 3 }} />
                <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: 2 }}>
                  Documenten
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                  {space.documents.map((document, index) => (
                    <Tooltip title={`Document ${index + 1}`} key={index}>
                      <Box
                        onClick={() => handleOpen(`http://localhost:5000/${document}`)}
                        sx={{
                          display: 'flex',
                          alignItems: 'center',
                          cursor: 'pointer',
                          color: '#1976d2',
                          '&:hover': {
                            textDecoration: 'underline',
                          },
                        }}
                      >
                        <PictureAsPdfIcon sx={{ mr: 1 }} />
                        <Typography>Document {index + 1}</Typography>
                      </Box>
                    </Tooltip>
                  ))}
                </Box>
              </>
            )}
          </CardContent>
        </Card>
      ))}
      <Modal
        open={open}
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{ timeout: 500 }}
      >
        <Fade in={open}>
          <Box
            sx={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              width: '80%',
              maxHeight: '90vh',
              bgcolor: 'background.paper',
              boxShadow: 24,
              p: 4,
              display: 'flex',
              flexDirection: 'column',
              overflow: 'auto',
              borderRadius: 2,
            }}
          >
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <IconButton onClick={handleClose}>
                <CloseIcon />
              </IconButton>
            </Box>
            {selectedFile.endsWith('.pdf') ? (
              <Box sx={{ textAlign: 'center' }}>
                <embed src={selectedFile} type="application/pdf" width="100%" height="600px" />
              </Box>
            ) : (
              <img
                src={selectedFile}
                alt="Selected"
                style={{ maxWidth: '100%', maxHeight: '80vh', height: 'auto', margin: '0 auto' }}
              />
            )}
            <Button onClick={handleClose} variant="contained" color="primary" sx={{ mt: 3 }}>
              Sluiten
            </Button>
          </Box>
        </Fade>
      </Modal>
    </Box>
  );
};

export default Spaces;
