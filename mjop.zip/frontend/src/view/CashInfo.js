import React from 'react';
import { Typography, Grid, Box } from '@mui/material';
import { calculateCurrentCash, getSaldoColor } from './dataHandling';

const CashInfo = ({ cashInfo, globalElements }) => {
  const formatCurrency = (value) => `€${parseFloat(value).toLocaleString()}`;
  const formatDate = (date) => new Date(date).toLocaleDateString();
  const currentCash = calculateCurrentCash(cashInfo, globalElements);
  const saldoColor = getSaldoColor(currentCash, cashInfo.totalWorth);

  return (
    <Box mb={4}>
      <Typography variant="h5" gutterBottom>
        Cash Information
      </Typography>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          <Typography>
            <strong>Current Cash: </strong>
            {formatCurrency(cashInfo.currentCash)}
          </Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography>
            <strong>Monthly Contribution: </strong>
            {formatCurrency(cashInfo.monthlyContribution)}
          </Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography>
            <strong>Reserve Date: </strong>
            {formatDate(cashInfo.reserveDate)}
          </Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography>
            <strong>Total Worth: </strong>
            {formatCurrency(cashInfo.totalWorth)}
          </Typography>
        </Grid>
      </Grid>
      <Box mt={4}>
        <Typography variant="h6" gutterBottom>
          Calculated Current Cash
        </Typography>
        <Typography variant="h4" className={saldoColor} sx={{ p: 2, color: 'white' }}>
          {formatCurrency(currentCash)}
        </Typography>
      </Box>
    </Box>
  );
};

export default CashInfo;
