import React, { useState } from 'react';
import {
  Typography,
  Card,
  CardContent,
  Box,
  List,
  ListItem,
  ListItemText,
  Modal,
  IconButton,
  Divider,
} from '@mui/material';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import AddPhotoAlternateIcon from '@mui/icons-material/AddPhotoAlternate';
import DownloadIcon from '@mui/icons-material/Download';
import ClearIcon from '@mui/icons-material/Clear';

const Elements = ({ globalSpaces = [], globalElements = [] }) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [open, setOpen] = useState(false);

  const handleOpen = (file) => {
    setSelectedFile(file);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setSelectedFile(null);
  };

  return (
    <Box mb={4} sx={{ p: 4, bgcolor: '#f5f5f5', borderRadius: 2 }}>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold', mb: 3, color: '#333' }}>
        Ruimtes en Elementen
      </Typography>
      {globalSpaces.map((space) => {
        const spaceElements = globalElements.filter((element) => element.spaceId === space.id);
        return (
          <Card key={space.id} sx={{ mb: 3, borderRadius: 2, overflow: 'visible' }}>
            <CardContent>
              <Typography variant="h5" sx={{ fontWeight: 'bold', mb: 2 }}>
                {space.name}
              </Typography>
              <Typography variant="body1" color="textSecondary" sx={{ mb: 2 }}>
                Beschrijving: {space.description}
              </Typography>

              <Box mt={2}>
                <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold', color: '#1976d2' }}>
                  Elementen
                </Typography>
                <List>
                  {spaceElements.length > 0 ? (
                    spaceElements.map((element) => (
                      <Box key={element.id} mb={2}>
                        <ListItem>
                          <ListItemText
                            primary={<Typography variant="h6">{element.name}</Typography>}
                            secondary={
                              <>
                                <Typography variant="body2" color="textSecondary">
                                  Beschrijving: {element.description}
                                </Typography>
                              </>
                            }
                          />
                        </ListItem>
                        <Box ml={4}>
                          <Typography variant="subtitle1" gutterBottom>
                            Bestanden
                          </Typography>
                          <List>
                            {(element.documents || []).map((file, index) => (
                              <ListItem key={index} button onClick={() => handleOpen(file)}>
                                <ListItemText primary={file.name} />
                                <IconButton>
                                  {file.type === 'image' ? (
                                    <AddPhotoAlternateIcon />
                                  ) : (
                                    <InsertDriveFileIcon />
                                  )}
                                </IconButton>
                              </ListItem>
                            ))}
                          </List>
                        </Box>
                        <Divider />
                      </Box>
                    ))
                  ) : (
                    <Typography variant="body2" color="textSecondary">
                      Geen elementen beschikbaar.
                    </Typography>
                  )}
                </List>
              </Box>
            </CardContent>
          </Card>
        );
      })}

      <Modal open={open} onClose={handleClose}>
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: '80%',
            bgcolor: 'background.paper',
            boxShadow: 24,
            p: 4,
          }}
        >
          {selectedFile && selectedFile.type === 'image' ? (
            <Box display="flex" flexDirection="column" alignItems="center">
              <img
                src={`http://localhost:5000/${selectedFile.path}`}
                alt={selectedFile.name}
                style={{ width: '100%', height: 'auto', objectFit: 'contain', marginBottom: '16px' }}
              />
              <Box display="flex" justifyContent="center">
                <IconButton
                  size="small"
                  onClick={() => {
                    const link = document.createElement('a');
                    link.href = `http://localhost:5000/${selectedFile.path}`;
                    link.download = selectedFile.name;
                    link.click();
                  }}
                >
                  <DownloadIcon />
                </IconButton>
                <IconButton
                  size="small"
                  color="secondary"
                  onClick={handleClose}
                  style={{
                    position: 'absolute',
                    top: 0,
                    right: 0,
                    background: 'rgba(255, 255, 255, 0.7)',
                  }}
                >
                  <ClearIcon fontSize="small" />
                </IconButton>
              </Box>
            </Box>
          ) : (
            <Box display="flex" flexDirection="column" alignItems="center">
              <InsertDriveFileIcon style={{ fontSize: '64px', marginBottom: '16px' }} />
              <Typography variant="h6" component="p" gutterBottom>
                {selectedFile?.name}
              </Typography>
              <Box display="flex" justifyContent="center">
                <IconButton
                  size="small"
                  onClick={() => {
                    const link = document.createElement('a');
                    link.href = `http://localhost:5000/${selectedFile.path}`;
                    link.download = selectedFile.name;
                    link.click();
                  }}
                >
                  <DownloadIcon />
                </IconButton>
                <IconButton
                  size="small"
                  color="secondary"
                  onClick={handleClose}
                  style={{
                    position: 'absolute',
                    top: 0,
                    right: 0,
                    background: 'rgba(255, 255, 255, 0.7)',
                  }}
                >
                  <ClearIcon fontSize="small" />
                </IconButton>
              </Box>
            </Box>
          )}
        </Box>
      </Modal>
    </Box>
  );
};

export default Elements;
