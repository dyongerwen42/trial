import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  CircularProgress,
  Box,
  Tabs,
  Tab,
  Badge,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button
} from '@mui/material';
import GeneralInfo from './GeneralInfo';
import CashInfo from './CashInfo';
import Spaces from './Spaces';
import Elements from './Elements';
import Documents from './Documents';
import InspectionReports from './InspectionReports';
import ElementsConditions from './ElementsConditions';

const ViewMJOP = () => {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedTab, setSelectedTab] = useState(0);
  const [tabErrors, setTabErrors] = useState({
    generalInfo: false,
    cashInfo: false,
    spaces: false,
    elements: false,
    inspectionReports: false,
    documents: false,
    elementsConditions: false,
  });
  const [openErrorDialog, setOpenErrorDialog] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/mjop/${id}`, { withCredentials: true });
        setData(response.data);
        setLoading(false);
      } catch (err) {
        setError(err);
        setLoading(false);
      }
    };

    fetchData();
  }, [id]);

  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <CircularProgress />
      </Container>
    );
  }

  if (error) {
    return <Typography>Fout bij het laden van gegevens: {error.message}</Typography>;
  }

  if (!data) {
    return <Typography>Geen gegevens beschikbaar</Typography>;
  }

  const { generalInfo, cashInfo, globalElements, globalSpaces, globalDocuments } = data;

  const sections = [
    'Algemene Informatie',
    'Financiële Informatie',
    'Ruimtes',
    'Elementen',
    'Documenten',
    'Inspectierapporten',
    'Elementen en Condities'
  ];

  const inspectionReportsData = globalElements.flatMap((element) =>
    element.inspectionReport.map((report) => ({
      Element: element.name,
      RapportNaam: report.name,
      Beschrijving: report.description,
      Conditie: report.condition,
      Urgentie: report.urgency,
      Type: report.elementType,
      Functie: report.elementFunction,
      Eenheid: report.unit,
      GeschattePrijs: report.estimatedPrice,
      Opmerkingen: report.remarks,
    }))
  );

  const elementsData = globalElements.map((element) => ({
    Naam: element.name,
    Beschrijving: element.description,
    Conditie: element.inspectionReport.map((report) => report.condition).join(', '),
  }));

  const renderSection = () => {
    switch (sections[selectedTab]) {
      case 'Algemene Informatie':
        return <GeneralInfo generalInfo={generalInfo} />;
      case 'Financiële Informatie':
        return <CashInfo cashInfo={cashInfo} globalElements={globalElements} />;
      case 'Ruimtes':
        return <Spaces globalSpaces={globalSpaces} />;
      case 'Elementen':
        return <Elements globalSpaces={globalSpaces} globalElements={globalElements} />;
      case 'Documenten':
        return <Documents globalDocuments={globalDocuments} />;
      case 'Inspectierapporten':
        return <InspectionReports inspectionReportsData={inspectionReportsData} />;
      case 'Elementen en Condities':
        return <ElementsConditions elementsData={elementsData} />;
      default:
        return null;
    }
  };

  const handleTabChange = (event, newValue) => {
    if (newValue === 1 && !cashInfo.currentCash) {
      setErrorMessage('Vul de financiële informatie in.');
      setOpenErrorDialog(true);
      return;
    }

    if (newValue === 2 && globalSpaces.length === 0) {
      setErrorMessage('Definieer ruimtes voordat u verder gaat.');
      setOpenErrorDialog(true);
      return;
    }

    if (newValue === 3 && globalElements.length === 0) {
      setErrorMessage('Definieer elementen voordat u verder gaat.');
      setOpenErrorDialog(true);
      return;
    }

    setSelectedTab(newValue);
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box display="flex" flexDirection="column" gap={2}>
        <Tabs
          value={selectedTab}
          onChange={handleTabChange}
          variant="scrollable"
          scrollButtons="auto"
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          {sections.map((section, index) => (
            <Tab
              key={section}
              label={
                <Badge
                  color="error"
                  variant="dot"
                  invisible={!tabErrors[section.toLowerCase().replace(/ /g, '')]}
                >
                  {section}
                </Badge>
              }
            />
          ))}
        </Tabs>
        <Paper elevation={3} sx={{ flexGrow: 1, p: 4, borderRadius: 2 }}>
          {renderSection()}
        </Paper>
      </Box>
      <Dialog
        open={openErrorDialog}
        onClose={() => setOpenErrorDialog(false)}
      >
        <DialogTitle>Fout</DialogTitle>
        <DialogContent>
          <Typography>{errorMessage}</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenErrorDialog(false)} color="primary">
            OK
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default ViewMJOP;

const TabPanel = (props) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};
