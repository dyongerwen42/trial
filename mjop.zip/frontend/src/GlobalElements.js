import React, { useState, useMemo, useEffect } from 'react';
import axios from 'axios';
import {
  Box,
  Button,
  TextField,
  Grid,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemText,
  Divider,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  useTheme,
  IconButton,
  Modal,
} from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ClearIcon from '@mui/icons-material/Clear';
import AddPhotoAlternateIcon from '@mui/icons-material/AddPhotoAlternate';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import DescriptionIcon from '@mui/icons-material/Description';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import DownloadIcon from '@mui/icons-material/Download';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useTable } from 'react-table';

import inspectionTasks from './inspectionTasks.json';

const extractGebreken = (elementName, type, material, data) => {
  const element = data.find(task => task.name === elementName);
  if (element && element.gebreken && element.gebreken[type] && element.gebreken[type][material]) {
    return element.gebreken[type][material];
  }
  return {};
};

const GlobalElements = ({
  t,
  globalElements,
  setGlobalElements,
  globalSpaces,
  availableElements,
  handleAddElement,
  handleEditElement,
  handleDeleteElement,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [newElement, setNewElement] = useState({
    id: '',
    name: '',
    description: '',
    interval: '',
    spaceId: '',
    type: '',
    material: '',
    customMaterial: '',
    photos: [],
    documents: [],
    gebreken: {},
    inspectionReport: [
      {
        id: '',
        description: '',
        inspectionDone: false,
        inspectionDate: null,
        tasks: [],
      },
    ],
  });
  const [imagePreviews, setImagePreviews] = useState([]);
  const [documentPreviews, setDocumentPreviews] = useState([]);
  const [errors, setErrors] = useState({});
  const [photosModalOpen, setPhotosModalOpen] = useState(false);
  const [documentsModalOpen, setDocumentsModalOpen] = useState(false);
  const [selectedPhotos, setSelectedPhotos] = useState([]);
  const [selectedDocuments, setSelectedDocuments] = useState([]);
  const [materials, setMaterials] = useState([]);
  const theme = useTheme();

  useEffect(() => {
    if (newElement.photos && newElement.photos.length > 0) {
      const previews = newElement.photos.map((file) => {
        if (typeof file === 'string') {
          return `http://localhost:5000/${file}`;
        } else if (file instanceof File) {
          return URL.createObjectURL(file);
        } else {
          return null;
        }
      }).filter((src) => src !== null);
      setImagePreviews(previews);
    } else {
      setImagePreviews([]);
    }

    if (newElement.documents && newElement.documents.length > 0) {
      const previews = newElement.documents.map((file) => {
        if (typeof file === 'string') {
          return `http://localhost:5000/${file}`;
        } else if (file instanceof File) {
          return URL.createObjectURL(file);
        } else {
          return null;
        }
      }).filter((src) => src !== null);
      setDocumentPreviews(previews);
    } else {
      setDocumentPreviews([]);
    }
  }, [newElement.photos, newElement.documents]);

  const filteredElements = useMemo(() => {
    return availableElements.filter(
      (element) =>
        element.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        element.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm, availableElements]);

  const columns = useMemo(
    () => [
      {
        Header: t('generateMJOP.elementName'),
        accessor: 'name',
      },
      {
        Header: t('generateMJOP.description'),
        accessor: 'description',
      },
      {
        Header: t('generateMJOP.interval'),
        accessor: 'interval',
      },
      {
        Header: t('generateMJOP.space'),
        accessor: 'spaceId',
        Cell: ({ value }) => {
          const space = globalSpaces.find((space) => space.id === value);
          return space ? space.name : '';
        },
      },
      {
        Header: t('generateMJOP.files'),
        accessor: 'files',
        Cell: ({ row }) => (
          <Box display="flex" justifyContent="center">
            <IconButton
              color="primary"
              onClick={() => handleOpenDocumentsModal(row.original.documents)}
            >
              <InsertDriveFileIcon />
            </IconButton>
            <IconButton
              color="primary"
              onClick={() => handleOpenPhotosModal(row.original.photos)}
            >
              <AddPhotoAlternateIcon />
            </IconButton>
          </Box>
        ),
      },
      {
        Header: t('generateMJOP.actions'),
        Cell: ({ row }) => (
          <Box display="flex" justifyContent="center">
            <IconButton
              color="primary"
              onClick={() => {
                handleSelectElement(row.original, true);
              }}
            >
              <EditIcon />
            </IconButton>
            <IconButton
              color="secondary"
              onClick={() => handleDeleteElement(row.original.id)}
            >
              <DeleteIcon />
            </IconButton>
          </Box>
        ),
      },
    ],
    [t, globalSpaces, handleDeleteElement]
  );

  const data = useMemo(() => globalElements, [globalElements]);

  const { getTableProps, getTableBodyProps, headerGroups, prepareRow, rows } =
    useTable({
      columns,
      data,
    });

  const handleSelectElement = (element, isEditMode = false) => {
    const types = Object.keys(inspectionTasks.find(task => task.name === element.name)?.gebreken || {});
    const materials = Object.keys(inspectionTasks.find(task => task.name === element.name)?.gebreken[element.type] || {});
    setNewElement({
      id: isEditMode ? element.id : '',
      name: element.name,
      description: element.description,
      interval: element.interval,
      spaceId: element.spaceId,
      type: element.type || '',
      material: element.material || '',
      customMaterial: element.customMaterial || '',
      photos: element.photos || [],
      documents: element.documents || [],
      gebreken: element.gebreken || extractGebreken(element.name, element.type, element.material, inspectionTasks),
      inspectionReport: element.inspectionReport || [
        {
          id: '',
          description: '',
          inspectionDone: false,
          inspectionDate: null,
          tasks: [],
        },
      ],
    });
    setMaterials(materials);
    setIsEditing(isEditMode);
  };

  const uploadFile = async (file) => {
    const formData = new FormData();
    formData.append('file', file);
    try {
      const response = await axios.post('http://localhost:5000/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return response.data.filePath;
    } catch (error) {
      console.error('Error uploading file:', error);
      return null;
    }
  };

  const handleFileChange = async (e) => {
    const files = Array.from(e.target.files);
    const fileUrls = await Promise.all(files.map((file) => uploadFile(file)));
    setNewElement({
      ...newElement,
      photos: [...(newElement.photos || []), ...fileUrls.filter((url) => url !== null)],
    });
  };

  const handleDocumentChange = async (e) => {
    const files = Array.from(e.target.files);
    const fileUrls = await Promise.all(files.map((file) => uploadFile(file)));
    setNewElement({
      ...newElement,
      documents: [...(newElement.documents || []), ...fileUrls.filter((url) => url !== null)],
    });
  };

  const handleClearImage = (index) => {
    const updatedPhotos = Array.from(newElement.photos || []).filter((_, i) => i !== index);
    setNewElement({ ...newElement, photos: updatedPhotos });
    setImagePreviews(updatedPhotos.map((file) => (typeof file === 'string' ? `http://localhost:5000/${file}` : URL.createObjectURL(file))));
  };

  const handleClearDocument = (index) => {
    const updatedDocuments = Array.from(newElement.documents || []).filter((_, i) => i !== index);
    setNewElement({ ...newElement, documents: updatedDocuments });
    setDocumentPreviews(updatedDocuments.map((file) => (typeof file === 'string' ? `http://localhost:5000/${file}` : URL.createObjectURL(file))));
  };

  const resetNewElement = () => {
    setNewElement({
      id: '',
      name: '',
      description: '',
      interval: '',
      spaceId: '',
      type: '',
      material: '',
      customMaterial: '',
      photos: [],
      documents: [],
      gebreken: {},
      inspectionReport: [
        {
          id: '',
          description: '',
          inspectionDone: false,
          inspectionDate: null,
          tasks: [],
        },
      ],
    });
    setImagePreviews([]);
    setDocumentPreviews([]);
    setErrors({});
    setIsEditing(false);
  };

  const handleSaveElement = () => {
    const newErrors = {};

    if (!newElement.name) newErrors.name = t('generateMJOP.nameRequired');
    if (!newElement.description) newErrors.description = t('generateMJOP.descriptionRequired');
    if (!newElement.interval) newErrors.interval = t('generateMJOP.intervalRequired');
    if (!newElement.spaceId) newErrors.spaceId = t('generateMJOP.spaceRequired');
    if (!newElement.type) newErrors.type = t('generateMJOP.typeRequired');
    if (!newElement.material) newErrors.material = t('generateMJOP.materialRequired');
    if (newElement.material === 'Other' && !newElement.customMaterial) newErrors.customMaterial = t('generateMJOP.customMaterialRequired');

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    if (isEditing) {
      handleEditElement(newElement);
    } else {
      handleAddElement(newElement);
    }
    resetNewElement();
  };

  const handleOpenPhotosModal = (photos) => {
    setSelectedPhotos(photos.map((photo) => (typeof photo === 'string' ? `http://localhost:5000/${photo}` : URL.createObjectURL(photo))));
    setPhotosModalOpen(true);
  };

  const handleOpenDocumentsModal = (documents) => {
    setSelectedDocuments(documents.map((doc) => (typeof doc === 'string' ? `http://localhost:5000/${doc}` : URL.createObjectURL(doc))));
    setDocumentsModalOpen(true);
  };

  const handleClosePhotosModal = () => setPhotosModalOpen(false);

  const handleCloseDocumentsModal = () => setDocumentsModalOpen(false);

  useEffect(() => {
    const handleResize = () => {
      const sidebar = document.querySelector('.sidebar');
      const content = document.querySelector('.content');
      if (sidebar && content) {
        sidebar.style.height = `${content.clientHeight}px`;
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const handleTypeChange = (e) => {
    const selectedType = e.target.value;
    const materials = Object.keys(inspectionTasks.find(task => task.name === newElement.name)?.gebreken[selectedType] || {});
    setMaterials(materials);
    setNewElement({
      ...newElement,
      type: selectedType,
      material: '',
      gebreken: {},
    });
  };

  const handleMaterialChange = (e) => {
    const selectedMaterial = e.target.value;
    const gebreken = extractGebreken(newElement.name, newElement.type, selectedMaterial, inspectionTasks);
    setNewElement({
      ...newElement,
      material: selectedMaterial,
      gebreken,
    });
  };

  return (
    <Box display="flex">
      {isSidebarOpen && (
        <Paper
          className="sidebar"
          sx={{ width: '25%', maxHeight: '100vh', overflowY: 'auto', p: 2 }}
        >
          <Typography variant="h6" gutterBottom>
            {t('generateMJOP.availableElements')}
          </Typography>
          <TextField
            fullWidth
            variant="outlined"
            placeholder={t('generateMJOP.searchElements')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            sx={{ mb: 2 }}
          />
          <List>
            {filteredElements.map((element) => (
              <React.Fragment key={element.id}>
                <ListItem button onClick={() => handleSelectElement(element, true)}>
                  <ListItemText
                    primary={element.name}
                    secondary={element.description}
                  />
                </ListItem>
                <Divider />
              </React.Fragment>
            ))}
          </List>
        </Paper>
      )}
      <Box
        className="content"
        component="section"
        sx={{ width: isSidebarOpen ? '75%' : '100%', p: 2 }}
      >
        <Button
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          variant="contained"
          startIcon={isSidebarOpen ? <ChevronLeftIcon /> : <ChevronRightIcon />}
        >
          {isSidebarOpen ? t('generateMJOP.closeSidebar') : t('generateMJOP.openSidebar')}
        </Button>
        <Typography variant="h5" sx={{ mt: 2, mb: 2 }}>
          {t('generateMJOP.globalElements')}
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              variant="outlined"
              label={t('generateMJOP.newElementName')}
              value={newElement.name}
              onChange={(e) =>
                setNewElement({ ...newElement, name: e.target.value })
              }
              error={!!errors.name}
              helperText={errors.name}
              sx={{ mb: 2 }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              variant="outlined"
              type="number"
              label={t('generateMJOP.inspectionInterval')}
              value={newElement.interval}
              onChange={(e) =>
                setNewElement({ ...newElement, interval: e.target.value })
              }
              error={!!errors.interval}
              helperText={errors.interval}
              sx={{ mb: 2 }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <FormControl fullWidth variant="outlined" error={!!errors.spaceId} sx={{ mb: 2 }}>
              <InputLabel>{t('generateMJOP.selectSpace')}</InputLabel>
              <Select
                value={newElement.spaceId}
                onChange={(e) =>
                  setNewElement({ ...newElement, spaceId: e.target.value })
                }
                label={t('generateMJOP.selectSpace')}
              >
                <MenuItem value="">
                  <em>{t('generateMJOP.selectSpace')}</em>
                </MenuItem>
                {globalSpaces.map((space) => (
                  <MenuItem key={space.id} value={space.id}>
                    {space.name}
                  </MenuItem>
                ))}
              </Select>
              {errors.spaceId && <Typography color="error">{errors.spaceId}</Typography>}
            </FormControl>
          </Grid>
          <Grid item xs={12} md={6}>
            <FormControl fullWidth variant="outlined" error={!!errors.type} sx={{ mb: 2 }}>
              <InputLabel>{t('generateMJOP.selectType')}</InputLabel>
              <Select
                value={newElement.type}
                onChange={handleTypeChange}
                label={t('generateMJOP.selectType')}
              >
                {Object.keys(inspectionTasks.find(task => task.name === newElement.name)?.gebreken || {}).map((type, index) => (
                  <MenuItem key={index} value={type}>
                    {type}
                  </MenuItem>
                ))}
              </Select>
              {errors.type && <Typography color="error">{errors.type}</Typography>}
            </FormControl>
          </Grid>
          <Grid item xs={12} md={6}>
            <FormControl fullWidth variant="outlined" error={!!errors.material} sx={{ mb: 2 }}>
              <InputLabel>{t('generateMJOP.selectMaterial')}</InputLabel>
              <Select
                value={newElement.material}
                onChange={handleMaterialChange}
                label={t('generateMJOP.selectMaterial')}
              >
                {materials.map((material, index) => (
                  <MenuItem key={index} value={material}>
                    {material}
                  </MenuItem>
                ))}
                <MenuItem value="Other">{t('generateMJOP.other')}</MenuItem>
              </Select>
              {errors.material && <Typography color="error">{errors.material}</Typography>}
            </FormControl>
          </Grid>
          {newElement.material === 'Other' && (
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                variant="outlined"
                label={t('generateMJOP.customMaterial')}
                value={newElement.customMaterial}
                onChange={(e) =>
                  setNewElement({ ...newElement, customMaterial: e.target.value })
                }
                error={!!errors.customMaterial}
                helperText={errors.customMaterial}
                sx={{ mb: 2 }}
              />
            </Grid>
          )}
          <Grid item xs={12}>
            <TextField
              fullWidth
              variant="outlined"
              label={t('generateMJOP.newElementDescription')}
              multiline
              rows={4}
              value={newElement.description}
              onChange={(e) =>
                setNewElement({ ...newElement, description: e.target.value })
              }
              error={!!errors.description}
              helperText={errors.description}
              sx={{ mb: 2 }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <FormControl fullWidth>
              <Button variant="contained" component="label" startIcon={<AddPhotoAlternateIcon />} sx={{ mb: 2 }}>
                {t('generateMJOP.uploadPhotos')}
                <input
                  type="file"
                  hidden
                  multiple
                  accept="image/*"
                  onChange={handleFileChange}
                />
              </Button>
              <Box display="flex" flexWrap="wrap" mt={2}>
                {imagePreviews.map((src, index) => (
                  <Box key={index} position="relative" mr={2} mb={2}>
                    <img
                      src={src}
                      alt={`preview ${index}`}
                      style={{ width: '100px', height: '100px', objectFit: 'contain' }}
                    />
                    <Box display="flex" justifyContent="center" mt={1}>
                      <IconButton
                        size="small"
                        onClick={() => {
                          const link = document.createElement('a');
                          link.href = src;
                          link.download = `image-${index}`;
                          link.click();
                        }}
                      >
                          <DownloadIcon />
                      </IconButton>
                      <IconButton
                        size="small"
                        onClick={() => handleClearImage(index)}
                      >
                        <ClearIcon />
                      </IconButton>
                    </Box>
                  </Box>
                ))}
              </Box>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={6}>
            <FormControl fullWidth>
              <Button variant="contained" component="label" startIcon={<InsertDriveFileIcon />} sx={{ mb: 2 }}>
                {t('generateMJOP.uploadDocuments')}
                <input
                  type="file"
                  hidden
                  multiple
                  accept=".pdf,.doc,.docx,.txt"
                  onChange={handleDocumentChange}
                />
              </Button>
              <Box display="flex" flexWrap="wrap" mt={2}>
                {documentPreviews.map((src, index) => {
                  const file = newElement.documents[index];
                  const fileType = file.type?.split('/')[1];
                  let icon;
                  if (fileType === 'pdf') {
                    icon = <PictureAsPdfIcon style={{ fontSize: 40 }} />;
                  } else if (fileType === 'msword' || fileType === 'vnd.openxmlformats-officedocument.wordprocessingml.document') {
                    icon = <DescriptionIcon style={{ fontSize: 40 }} />;
                  } else {
                    icon = <InsertDriveFileIcon style={{ fontSize: 40 }} />;
                  }
  
                  return (
                    <Box key={index} position="relative" mr={2} mb={2}>
                      <a href={src} download style={{ margin: '0 8px' }}>
                        {icon}
                      </a>
                      <Box display="flex" justifyContent="center" mt={1}>
                        <IconButton
                          size="small"
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = src;
                            link.download = `document-${index}`;
                            link.click();
                          }}
                        >
                          <DownloadIcon />
                        </IconButton>
                        <IconButton
                          size="small"
                          onClick={() => handleClearDocument(index)}
                        >
                          <ClearIcon />
                        </IconButton>
                      </Box>
                    </Box>
                  );
                })}
              </Box>
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <Button
              onClick={handleSaveElement}
              variant="contained"
              color="primary"
              fullWidth
              sx={{ mt: 2 }}
            >
              {isEditing
                ? t('generateMJOP.updateElement')
                : t('generateMJOP.addElement')}
            </Button>
          </Grid>
        </Grid>
        <Box sx={{ overflowY: 'auto', maxHeight: 'calc(100vh - 200px)', mt: 4 }}>
          <table {...getTableProps()} style={{ width: '100%' }}>
            <thead>
              {headerGroups.map((headerGroup) => (
                <tr {...headerGroup.getHeaderGroupProps()}>
                  {headerGroup.headers.map((column) => (
                    <th
                      {...column.getHeaderProps()}
                      style={{
                        padding: theme.spacing(1),
                        borderBottom: '1px solid #e0e0e0',
                        textAlign: 'left',
                        backgroundColor: '#000000',
                        color: '#ffffff',
                      }}
                    >
                      {column.render('Header')}
                    </th>
                  ))}
                </tr>
              ))}
            </thead>
            <tbody {...getTableBodyProps()}>
              {rows.map((row) => {
                prepareRow(row);
                return (
                  <tr {...row.getRowProps()}>
                    {row.cells.map((cell) => (
                      <td
                        {...cell.getCellProps()}
                        style={{
                          padding: theme.spacing(1),
                          borderBottom: '1px solid #e0e0e0',
                        }}
                      >
                        {cell.render('Cell')}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Box>
  
        {/* Photos Modal */}
        <Modal open={photosModalOpen} onClose={handleClosePhotosModal}>
          <Box sx={{ ...modalStyle, width: 400 }}>
            <Typography variant="h6" component="h2" gutterBottom>
              {t('generateMJOP.viewPhotos')}
            </Typography>
            <Box display="flex" flexDirection="column" alignItems="center">
              {selectedPhotos.map((src, index) => (
                <Box key={index} position="relative" mb={2} textAlign="center">
                  <img src={src} alt={`Photo ${index}`} style={{ width: '100%', height: 'auto', objectFit: 'contain', marginBottom: theme.spacing(1) }} />
                  <IconButton
                    size="small"
                    onClick={() => {
                      const link = document.createElement('a');
                      link.href = src;
                      link.download = `photo-${index}`;
                      link.click();
                    }}
                  >
                    <DownloadIcon />
                  </IconButton>
                </Box>
              ))}
            </Box>
            <Button onClick={handleClosePhotosModal} variant="contained" color="primary" fullWidth>
              {t('generateMJOP.close')}
            </Button>
          </Box>
        </Modal>
  
        {/* Documents Modal */}
        <Modal open={documentsModalOpen} onClose={handleCloseDocumentsModal}>
          <Box sx={{ ...modalStyle, width: 400 }}>
            <Typography variant="h6" component="h2" gutterBottom>
              {t('generateMJOP.viewDocuments')}
            </Typography>
            <Box display="flex" flexDirection="column" alignItems="center">
              {selectedDocuments.map((src, index) => {
                const fileType = src.split('.').pop();
                let icon;
                if (fileType === 'pdf') {
                  icon = <PictureAsPdfIcon style={{ fontSize: 40 }} />;
                } else if (fileType === 'doc' || fileType === 'docx') {
                  icon = <DescriptionIcon style={{ fontSize: 40 }} />;
                } else {
                  icon = <InsertDriveFileIcon style={{ fontSize: 40 }} />;
                }
                return (
                  <Box key={index} position="relative" mb={2} textAlign="center">
                    <a href={src} download>
                      {icon}
                    </a>
                    <IconButton
                      size="small"
                      onClick={() => {
                        const link = document.createElement('a');
                        link.href = src;
                        link.download = `document-${index}`;
                        link.click();
                      }}
                    >
                        <DownloadIcon />
                    </IconButton>
                  </Box>
                );
              })}
            </Box>
            <Button onClick={handleCloseDocumentsModal} variant="contained" color="primary" fullWidth>
              {t('generateMJOP.close')}
            </Button>
          </Box>
        </Modal>
      </Box>
    </Box>
  );
  
  
  
};

const modalStyle = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  bgcolor: 'background.paper',
  boxShadow: 24,
  p: 4,
};

export default GlobalElements;

