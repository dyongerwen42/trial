import React, { useState, useEffect, useMemo } from 'react';
import {
  Box,
  Button,
  TextField,
  Grid,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemText,
  Divider,
  IconButton,
  useTheme,
  FormControl,
  InputLabel,
  OutlinedInput,
  Modal,
  Backdrop,
  Fade,
} from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ClearIcon from '@mui/icons-material/Clear';
import AddPhotoAlternateIcon from '@mui/icons-material/AddPhotoAlternate';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import DownloadIcon from '@mui/icons-material/Download';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useTable } from 'react-table';
import axios from 'axios';

const GlobalSpaces = ({
  t,
  availableSpaces,
  globalSpaces,
  setGlobalSpaces,
  newSpace,
  setNewSpace,
  handleAddSpace,
  handleEditSpace,
  handleDeleteSpace,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [imagePreviews, setImagePreviews] = useState([]);
  const [documentPreviews, setDocumentPreviews] = useState([]);
  const [errors, setErrors] = useState({});
  const [openModal, setOpenModal] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const theme = useTheme();

  useEffect(() => {
    if (newSpace.photos && newSpace.photos.length > 0) {
      const previews = newSpace.photos.map((file) => {
        if (typeof file === 'string') {
          return `http://localhost:5000/${file}`;
        } else if (file instanceof File) {
          return URL.createObjectURL(file);
        } else {
          return null;
        }
      }).filter((src) => src !== null);
      setImagePreviews(previews);
    } else {
      setImagePreviews([]);
    }

    if (newSpace.documents && newSpace.documents.length > 0) {
      const previews = newSpace.documents.map((file) => {
        if (typeof file === 'string') {
          return `http://localhost:5000/${file}`;
        } else if (file instanceof File) {
          return URL.createObjectURL(file);
        } else {
          return null;
        }
      }).filter((src) => src !== null);
      setDocumentPreviews(previews);
    } else {
      setDocumentPreviews([]);
    }
  }, [newSpace.photos, newSpace.documents]);

  const filteredSpaces = useMemo(() => {
    return availableSpaces.filter(
      (space) =>
        space.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        space.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm, availableSpaces]);

  const columns = useMemo(
    () => [
      {
        Header: t('generateMJOP.spaceName'),
        accessor: 'name',
      },
      {
        Header: t('generateMJOP.description'),
        accessor: 'description',
      },
      {
        Header: t('generateMJOP.files'),
        accessor: 'files',
        Cell: ({ row }) => (
          <Box display="flex" alignItems="center">
            <IconButton onClick={() => handleOpenModal(row.original.photos)}>
              <AddPhotoAlternateIcon />
            </IconButton>
            <IconButton onClick={() => handleOpenModal(row.original.documents)}>
              <InsertDriveFileIcon />
            </IconButton>
          </Box>
        ),
      },
      {
        Header: t('generateMJOP.actions'),
        Cell: ({ row }) => (
          <Box display="flex" justifyContent="space-around">
            <IconButton
              onClick={() => {
                setIsEditing(true);
                setNewSpace(row.original);
                handleEditSpace(row.original);
              }}
              color="primary"
            >
              <EditIcon />
            </IconButton>
            <IconButton
              onClick={() => handleDeleteSpace(row.original.id)}
              color="secondary"
            >
              <DeleteIcon />
            </IconButton>
          </Box>
        ),
      },
    ],
    [t, handleEditSpace, handleDeleteSpace]
  );

  const data = useMemo(() => globalSpaces, [globalSpaces]);

  const { getTableProps, getTableBodyProps, headerGroups, prepareRow, rows } = useTable({
    columns,
    data,
  });

  const handleSelectSpace = (space) => {
    setNewSpace({
      id: space.id,
      name: space.name,
      description: space.description,
      photos: space.photos || [],
      documents: space.documents || [],
    });
  };

  const handleFileChange = async (e) => {
    const files = Array.from(e.target.files);
    const uploadedFiles = await Promise.all(files.map(uploadFile));
    setNewSpace({ ...newSpace, photos: [...(newSpace.photos || []), ...uploadedFiles] });
  };

  const handleDocumentChange = async (e) => {
    const files = Array.from(e.target.files);
    const uploadedFiles = await Promise.all(files.map(uploadFile));
    setNewSpace({ ...newSpace, documents: [...(newSpace.documents || []), ...uploadedFiles] });
  };

  const uploadFile = async (file) => {
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await axios.post('http://localhost:5000/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      return response.data.filePath;
    } catch (error) {
      console.error('Error uploading file:', error);
      return null;
    }
  };

  const handleClearImage = (index) => {
    const updatedPhotos = Array.from(newSpace.photos || []).filter((_, i) => i !== index);
    setNewSpace({ ...newSpace, photos: updatedPhotos });
    setImagePreviews(updatedPhotos.map((file) => (typeof file === 'string' ? `http://localhost:5000/${file}` : URL.createObjectURL(file))));
  };

  const handleClearDocument = (index) => {
    const updatedDocuments = Array.from(newSpace.documents || []).filter((_, i) => i !== index);
    setNewSpace({ ...newSpace, documents: updatedDocuments });
    setDocumentPreviews(updatedDocuments.map((file) => (typeof file === 'string' ? `http://localhost:5000/${file}` : URL.createObjectURL(file))));
  };

  const resetNewSpace = () => {
    setNewSpace({
      id: '',
      name: '',
      description: '',
      photos: [],
      documents: [],
    });
    setImagePreviews([]);
    setDocumentPreviews([]);
    setErrors({});
    setIsEditing(false);
  };

  const handleSaveSpace = () => {
    const newErrors = {};

    if (!newSpace.name) newErrors.name = t('generateMJOP.nameRequired');
    if (!newSpace.description) newErrors.description = t('generateMJOP.descriptionRequired');

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    if (isEditing) {
      handleEditSpace(newSpace);
    } else {
      handleAddSpace(newSpace);
    }
    resetNewSpace();
  };

  const handleOpenModal = (files) => {
    setSelectedFiles(files);
    setOpenModal(true);
  };

  const handleCloseModal = () => {
    setOpenModal(false);
    setSelectedFiles([]);
  };

  const renderFilePreview = (file) => {
    const fileType = file.split('.').pop();
    if (fileType === 'pdf') {
      return <PictureAsPdfIcon style={{ fontSize: 40 }} />;
    } else {
      return <InsertDriveFileIcon style={{ fontSize: 40 }} />;
    }
  };

  const modalStyle = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '80%',
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 4,
  };

  return (
    <Box display="flex">
      {isSidebarOpen && (
        <Paper sx={{ width: '25%', maxHeight: '100vh', overflowY: 'auto', p: 2 }}>
          <Typography variant="h6" gutterBottom>
            {t('generateMJOP.availableSpaces')}
          </Typography>
          <TextField
            fullWidth
            variant="outlined"
            placeholder={t('generateMJOP.searchSpaces')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            sx={{ mb: 2 }}
          />
          <List>
            {filteredSpaces.map((space) => (
              <React.Fragment key={space.id}>
                <ListItem button onClick={() => handleSelectSpace(space)}>
                  <ListItemText primary={space.name} secondary={space.description} />
                </ListItem>
                <Divider />
              </React.Fragment>
            ))}
          </List>
        </Paper>
      )}
      <Box component="section" sx={{ width: isSidebarOpen ? '75%' : '100%', p: 2 }}>
        <Button
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          variant="contained"
          startIcon={isSidebarOpen ? <ChevronLeftIcon /> : <ChevronRightIcon />}
        >
          {isSidebarOpen ? t('generateMJOP.closeSidebar') : t('generateMJOP.openSidebar')}
        </Button>
        <Typography variant="h5" sx={{ mt: 2, mb: 2 }}>
          {t('generateMJOP.globalSpaces')}
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              variant="outlined"
              label={t('generateMJOP.newSpaceName')}
              value={newSpace.name}
              onChange={(e) => setNewSpace({ ...newSpace, name: e.target.value })}
              error={!!errors.name}
              helperText={errors.name}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              variant="outlined"
              label={t('generateMJOP.spaceDescription')}
              multiline
              rows={4}
              value={newSpace.description}
              onChange={(e) => setNewSpace({ ...newSpace, description: e.target.value })}
              error={!!errors.description}
              helperText={errors.description}
            />
          </Grid>
          <Grid item xs={12}>
            <FormControl fullWidth variant="outlined">
              <Button
                variant="contained"
                component="label"
                startIcon={<AddPhotoAlternateIcon />}
                sx={{ mb: 2 }}
              >
                {t('generateMJOP.uploadPhotos')}
                <input
                  type="file"
                  hidden
                  multiple
                  accept="image/*"
                  onChange={handleFileChange}
                />
              </Button>
              {imagePreviews.length > 0 && (
                <Box mt={2} display="flex" flexWrap="wrap">
                  {imagePreviews.map((src, index) => (
                    <Box key={index} position="relative" m={1}>
                      <img src={src} alt="Preview" style={{ width: 100, height: 100, objectFit: 'contain' }} />
                      <Box display="flex" justifyContent="center" mt={1}>
                        <IconButton
                          size="small"
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = src;
                            link.download = src.split('/').pop();
                            link.click();
                          }}
                        >
                          <DownloadIcon />
                        </IconButton>
                        <IconButton
                          size="small"
                          color="secondary"
                          onClick={() => handleClearImage(index)}
                          style={{
                            position: 'absolute',
                            top: 0,
                            right: 0,
                            background: 'rgba(255, 255, 255, 0.7)',
                          }}
                        >
                          <ClearIcon fontSize="small" />
                        </IconButton>
                      </Box>
                    </Box>
                  ))}
                </Box>
              )}
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <FormControl fullWidth variant="outlined">
              <Button
                variant="contained"
                component="label"
                startIcon={<InsertDriveFileIcon />}
                sx={{ mb: 2 }}
              >
                {t('generateMJOP.uploadDocuments')}
                <input
                  type="file"
                  hidden
                  multiple
                  accept=".pdf,.doc,.docx,.txt"
                  onChange={handleDocumentChange}
                />
              </Button>
              {documentPreviews.length > 0 && (
                <Box mt={2} display="flex" flexWrap="wrap">
                  {documentPreviews.map((src, index) => (
                    <Box key={index} position="relative" m={1}>
                      <a href={src} target="_blank" rel="noopener noreferrer">
                        {renderFilePreview(src)}
                      </a>
                      <Box display="flex" justifyContent="center" mt={1}>
                        <IconButton
                          size="small"
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = src;
                            link.download = src.split('/').pop();
                            link.click();
                          }}
                        >
                          <DownloadIcon />
                        </IconButton>
                        <IconButton
                          size="small"
                          color="secondary"
                          onClick={() => handleClearDocument(index)}
                          style={{
                            position: 'absolute',
                            top: 0,
                            right: 0,
                            background: 'rgba(255, 255, 255, 0.7)',
                          }}
                        >
                          <ClearIcon fontSize="small" />
                        </IconButton>
                      </Box>
                    </Box>
                  ))}
                </Box>
              )}
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <Button
              onClick={handleSaveSpace}
              variant="contained"
              color="primary"
              fullWidth
              sx={{ mt: 2 }}
            >
              {isEditing ? t('generateMJOP.updateSpace') : t('generateMJOP.addSpace')}
            </Button>
          </Grid>
        </Grid>
        <Box sx={{ overflowY: 'auto', maxHeight: 'calc(100vh - 200px)', mt: 4 }}>
          <table {...getTableProps()} style={{ width: '100%' }}>
            <thead>
              {headerGroups.map((headerGroup) => (
                <tr {...headerGroup.getHeaderGroupProps()}>
                  {headerGroup.headers.map((column) => (
                    <th
                      {...column.getHeaderProps()}
                      style={{
                        padding: theme.spacing(1),
                        borderBottom: '1px solid #e0e0e0',
                        textAlign: 'left',
                        backgroundColor: '#000000',
                        color: '#ffffff',
                      }}
                    >
                      {column.render('Header')}
                    </th>
                  ))}
                </tr>
              ))}
            </thead>
            <tbody {...getTableBodyProps()}>
              {rows.map((row) => {
                prepareRow(row);
                return (
                  <tr {...row.getRowProps()}>
                    {row.cells.map((cell) => (
                      <td
                        {...cell.getCellProps()}
                        style={{
                          padding: theme.spacing(1),
                          borderBottom: '1px solid #e0e0e0',
                        }}
                      >
                        {cell.render('Cell')}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Box>
      </Box>

      <Modal
        open={openModal}
        onClose={handleCloseModal}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={openModal}>
          <Box sx={modalStyle}>
            <Typography variant="h6" component="h2">
              {t('generateMJOP.files')}
            </Typography>
            <Box mt={2} display="flex" flexWrap="wrap">
              {selectedFiles.map((file, index) => {
                const fileType = file.split('.').pop();
                if (fileType === 'pdf') {
                  return (
                    <Box key={index} position="relative" m={1}>
                      <a href={`http://localhost:5000/${file}`} target="_blank" rel="noopener noreferrer">
                        <PictureAsPdfIcon style={{ fontSize: 40 }} />
                      </a>
                      <Box display="flex" justifyContent="center" mt={1}>
                        <IconButton
                          size="small"
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = `http://localhost:5000/${file}`;
                            link.download = file.split('/').pop();
                            link.click();
                          }}
                        >
                          <DownloadIcon />
                        </IconButton>
                      </Box>
                    </Box>
                  );
                } else {
                  return (
                    <Box key={index} position="relative" m={1}>
                      <img src={`http://localhost:5000/${file}`} alt="File" style={{ width: 100, height: 100, objectFit: 'contain' }} />
                      <Box display="flex" justifyContent="center" mt={1}>
                        <IconButton
                          size="small"
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = `http://localhost:5000/${file}`;
                            link.download = file.split('/').pop();
                            link.click();
                          }}
                        >
                          <DownloadIcon />
                        </IconButton>
                      </Box>
                    </Box>
                  );
                }
              })}
            </Box>
          </Box>
        </Fade>
      </Modal>
    </Box>
  );
};

export default GlobalSpaces;
