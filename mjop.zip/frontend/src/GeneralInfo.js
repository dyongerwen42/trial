import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { TextField, Grid, Box, Typography, Button, IconButton, Divider } from '@mui/material';
import ClearIcon from '@mui/icons-material/Clear';
import DownloadIcon from '@mui/icons-material/Download';

const GeneralInfo = ({ generalInfo, setGeneralInfo, errors, t }) => {
  const [imagePreview, setImagePreview] = useState(null);

  useEffect(() => {
    if (generalInfo.propertyImage) {
      setImagePreview(`http://localhost:5000/${generalInfo.propertyImage}`);
    } else {
      setImagePreview(null);
    }
  }, [generalInfo.propertyImage]);

  const handleClearImage = () => {
    setGeneralInfo((prev) => ({ ...prev, propertyImage: null }));
    setImagePreview(null);
  };

  const handleImageUpload = async (event) => {
    const file = event.target.files[0];
    if (file) {
      const formData = new FormData();
      formData.append('file', file);

      try {
        const response = await axios.post('http://localhost:5000/upload', formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
        const filePath = response.data.filePath;
        setGeneralInfo((prev) => ({ ...prev, propertyImage: filePath }));
        setImagePreview(`http://localhost:5000/${filePath}`);
      } catch (error) {
        console.error('Error uploading file:', error);
      }
    }
  };

  return (
    <Box component="section" sx={{ mt: 4, p: 3, backgroundColor: '#f5f5f5', borderRadius: '8px' }}>
      <Typography variant="h5" component="h3" sx={{ mb: 3, fontWeight: 'bold' }}>
        {t('generateMJOP.generalInfo')}
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Typography variant="h6" gutterBottom>
            {t('generateMJOP.projectDetails')}
          </Typography>
          <Divider sx={{ mb: 2 }} />
          {['projectNumber', 'projectName', 'address'].map((field) => (
            <TextField
              key={field}
              fullWidth
              label={t(`generateMJOP.${field}`)}
              variant="outlined"
              value={generalInfo[field]}
              onChange={(e) => setGeneralInfo((prev) => ({ ...prev, [field]: e.target.value }))}
              error={!!errors[field]}
              helperText={errors[field]}
              InputLabelProps={{ shrink: true }}
              sx={{ mb: 2 }}
            />
          ))}
        </Grid>
        <Grid item xs={12} md={6}>
          <Typography variant="h6" gutterBottom>
            {t('generateMJOP.vveContactPerson')}
          </Typography>
          <Divider sx={{ mb: 2 }} />
          {['contactPersonName', 'contactPersonEmail', 'contactPersonPhone'].map((field) => (
            <TextField
              key={field}
              fullWidth
              label={t(`generateMJOP.${field}`)}
              variant="outlined"
              value={generalInfo[field]}
              onChange={(e) => setGeneralInfo((prev) => ({ ...prev, [field]: e.target.value }))}
              error={!!errors[field]}
              helperText={errors[field]}
              InputLabelProps={{ shrink: true }}
              sx={{ mb: 2 }}
            />
          ))}
        </Grid>
        <Grid item xs={12} md={6}>
          <Typography variant="h6" gutterBottom>
            {t('generateMJOP.vveBeheerder')}
          </Typography>
          <Divider sx={{ mb: 2 }} />
          {['beheerderNaam', 'beheerderAdres', 'beheerderPostcode', 'beheerderPlaats', 'beheerderTelefoon', 'beheerderEmail'].map((field) => (
            <TextField
              key={field}
              fullWidth
              label={t(`generateMJOP.${field}`)}
              variant="outlined"
              value={generalInfo[field]}
              onChange={(e) => setGeneralInfo((prev) => ({ ...prev, [field]: e.target.value }))}
              error={!!errors[field]}
              helperText={errors[field]}
              InputLabelProps={{ shrink: true }}
              sx={{ mb: 2 }}
            />
          ))}
        </Grid>
        <Grid item xs={12}>
          <Typography variant="h6" gutterBottom>
            {t('generateMJOP.opmerkingen')}
          </Typography>
          <Divider sx={{ mb: 2 }} />
          <TextField
            fullWidth
            label={t('generateMJOP.opmerkingen')}
            variant="outlined"
            value={generalInfo.opmerkingen}
            onChange={(e) => setGeneralInfo((prev) => ({ ...prev, opmerkingen: e.target.value }))}
            multiline
            minRows={3}
            error={!!errors.opmerkingen}
            helperText={errors.opmerkingen}
            InputLabelProps={{ shrink: true }}
          />
        </Grid>
      </Grid>
      <Box sx={{ mt: 4 }}>
        <Typography variant="body1" component="label" sx={{ display: 'block', mb: 1 }}>
          {t('generateMJOP.propertyImage')}
        </Typography>
        <Button variant="contained" component="label" sx={{ mb: 2 }}>
          {t('generateMJOP.upload')}
          <input
            type="file"
            hidden
            onChange={handleImageUpload}
          />
        </Button>
        {imagePreview && (
          <Box sx={{ mt: 2, position: 'relative', display: 'inline-block' }}>
            <img
              src={imagePreview}
              alt="Property"
              style={{ width: '100%', height: 'auto', maxHeight: '400px', objectFit: 'cover', borderRadius: '8px' }}
            />
            <Box display="flex" justifyContent="center" mt={1}>
              <IconButton
                size="small"
                onClick={() => {
                  const link = document.createElement('a');
                  link.href = imagePreview;
                  link.download = `property-image`;
                  link.click();
                }}
              >
                <DownloadIcon />
              </IconButton>
              <IconButton
                size="small"
                onClick={handleClearImage}
                style={{
                  position: 'absolute',
                  top: 0,
                  right: 0,
                  backgroundColor: 'rgba(255, 255, 255, 0.7)',
                }}
              >
                <ClearIcon />
              </IconButton>
            </Box>
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default GeneralInfo;
