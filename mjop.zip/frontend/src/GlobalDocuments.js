import React from 'react';
import {
  Box,
  Typography,
  TextField,
  List,
  ListItem,
  ListItemText,
  Paper,
  IconButton,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import { useTranslation } from 'react-i18next';

const GlobalDocuments = ({ globalDocuments, setGlobalDocuments }) => {
  const { t } = useTranslation();

  const handleDeleteDocument = (index) => {
    const updatedDocuments = globalDocuments.filter((_, i) => i !== index);
    setGlobalDocuments(updatedDocuments);
  };

  return (
    <Box sx={{ mt: 4 }}>
      <Typography variant="h5" sx={{ mb: 2 }}>
        {t('generateMJOP.globalDocuments')}
      </Typography>
      <TextField
        type="file"
        inputProps={{ multiple: true }}
        onChange={(e) => setGlobalDocuments(Array.from(e.target.files))}
        variant="outlined"
        fullWidth
        sx={{ mb: 2 }}
      />
      <Paper variant="outlined">
        <List>
          {globalDocuments.map((doc, index) => (
            <ListItem key={index}>
              <ListItemText primary={doc.name} />
              <IconButton
                edge="end"
                aria-label="delete"
                onClick={() => handleDeleteDocument(index)}
              >
                <DeleteIcon />
              </IconButton>
            </ListItem>
          ))}
        </List>
      </Paper>
    </Box>
  );
};

export default GlobalDocuments;
