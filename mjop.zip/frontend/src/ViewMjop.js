import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import {
  Box, Typography, Card, CardContent, Grid, Divider, Paper, List, ListItem, ListItemText, Container, Stack, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button
} from '@mui/material';
import { calculateCurrentCash, getSaldoColor } from './dataHandling';
import * as XLSX from 'xlsx';

const ViewMJOP = () => {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/mjop/${id}`, { withCredentials: true });
        setData(response.data);
        setLoading(false);
      } catch (err) {
        setError(err);
        setLoading(false);
      }
    };

    fetchData();
  }, [id]);

  const exportToExcel = (tableData, fileName) => {
    const worksheet = XLSX.utils.json_to_sheet(tableData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
    XLSX.writeFile(workbook, `${fileName}.xlsx`);
  };

  if (loading) {
    return <Typography>Loading...</Typography>;
  }

  if (error) {
    return <Typography>Error loading data: {error.message}</Typography>;
  }

  if (!data) {
    return <Typography>No data available</Typography>;
  }

  const { generalInfo, cashInfo, globalElements, globalSpaces, globalDocuments } = data;

  const formatCurrency = (value) => `€${parseFloat(value).toLocaleString()}`;
  const formatDate = (date) => new Date(date).toLocaleDateString();
  const currentCash = calculateCurrentCash(cashInfo, globalElements);
  const saldoColor = getSaldoColor(currentCash, cashInfo.totalWorth);

  const elementsData = globalElements.map((element) => ({
    Name: element.name,
    Description: element.description,
    Condition: element.inspectionReport.map((report) => report.condition).join(', '),
  }));

  const inspectionReportsData = globalElements.flatMap((element) =>
    element.inspectionReport.map((report) => ({
      Element: element.name,
      ReportName: report.name,
      Description: report.description,
      Condition: report.condition,
      Urgency: report.urgency,
      Type: report.elementType,
      Function: report.elementFunction,
      Unit: report.unit,
      EstimatedPrice: report.estimatedPrice,
      Remarks: report.remarks,
    }))
  );

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Paper elevation={3} sx={{ p: 4, borderRadius: 2 }}>
        <Typography variant="h4" gutterBottom align="center" sx={{ mb: 4 }}>
          MJOP Report
        </Typography>

        <Box mb={4}>
          <Typography variant="h5" gutterBottom>
            General Information
          </Typography>
          <Grid container spacing={2}>
            {Object.entries(generalInfo).map(([key, value]) => (
              <Grid item xs={12} sm={6} key={key}>
                <Typography>
                  <strong>{key.replace(/([A-Z])/g, ' $1').toUpperCase()}: </strong>
                  {value}
                </Typography>
              </Grid>
            ))}
          </Grid>
        </Box>

        <Divider sx={{ mb: 4 }} />

        <Box mb={4}>
          <Typography variant="h5" gutterBottom>
            Cash Information
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <Typography>
                <strong>Current Cash: </strong>
                {formatCurrency(cashInfo.currentCash)}
              </Typography>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography>
                <strong>Monthly Contribution: </strong>
                {formatCurrency(cashInfo.monthlyContribution)}
              </Typography>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography>
                <strong>Reserve Date: </strong>
                {formatDate(cashInfo.reserveDate)}
              </Typography>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography>
                <strong>Total Worth: </strong>
                {formatCurrency(cashInfo.totalWorth)}
              </Typography>
            </Grid>
          </Grid>
          <Box mt={4}>
            <Typography variant="h6" gutterBottom>
              Calculated Current Cash
            </Typography>
            <Typography variant="h4" className={saldoColor} sx={{ p: 2, color: 'white' }}>
              {formatCurrency(currentCash)}
            </Typography>
          </Box>
        </Box>

        <Divider sx={{ mb: 4 }} />

        <Box mb={4}>
          <Typography variant="h5" gutterBottom>
            Spaces
          </Typography>
          {globalSpaces.map((space) => (
            <Card key={space.id} sx={{ mb: 2 }}>
              <CardContent>
                <Typography variant="h6">{space.name}</Typography>
                <Typography>Description: {space.description}</Typography>
              </CardContent>
            </Card>
          ))}
        </Box>

        <Divider sx={{ mb: 4 }} />

        <Box mb={4}>
          <Typography variant="h5" gutterBottom>
            Elements
          </Typography>
          {globalElements.map((element) => (
            <Card key={element.id} sx={{ mb: 2 }}>
              <CardContent>
                <Typography variant="h6">{element.name}</Typography>
                <Typography>Description: {element.description}</Typography>
                <Typography>Interval: {element.interval} months</Typography>

                <Box mt={2}>
                  <Typography variant="subtitle1" gutterBottom>
                    Inspection Reports
                  </Typography>
                  {element.inspectionReport.map((report) => (
                    <Box key={report.id} mb={2} sx={{ pl: 2, borderLeft: '4px solid', borderColor: 'primary.main' }}>
                      <Typography variant="h6" gutterBottom>{report.name}</Typography>
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={6}>
                          <Typography>Description: {report.description}</Typography>
                          <Typography>Condition: {report.condition}</Typography>
                          <Typography>Urgency: {report.urgency}</Typography>
                          <Typography>Type: {report.elementType}</Typography>
                          <Typography>Function: {report.elementFunction}</Typography>
                          <Typography>Unit: {report.unit}</Typography>
                          <Typography>Estimated Price: {formatCurrency(report.estimatedPrice)}</Typography>
                          <Typography>Remarks: {report.remarks}</Typography>
                        </Grid>
                      </Grid>

                      <Box mt={2}>
                        <Typography variant="subtitle2" gutterBottom>
                          Tasks
                        </Typography>
                        <List>
                          {report.tasks.map((task) => (
                            <ListItem key={task.id} sx={{ pl: 2, mb: 1, borderLeft: '4px solid', borderColor: 'secondary.main' }}>
                              <ListItemText
                                primary={<Typography variant="body1">{task.name}</Typography>}
                                secondary={
                                  <Stack spacing={1}>
                                    <Typography>Description: {task.description}</Typography>
                                    <Typography>Estimated Price: {formatCurrency(task.estimatedPrice)}</Typography>
                                    <Typography>Urgency: {task.urgency}</Typography>
                                    <Typography>Ultimate Date: {formatDate(task.ultimateDate)}</Typography>
                                    <Typography>Work Date: {formatDate(task.planned.workDate)}</Typography>
                                    <Typography>Planned Price: {formatCurrency(task.planned.estimatedPrice)}</Typography>
                                    <Typography>Comment: {task.planned.comment}</Typography>
                                  </Stack>
                                }
                              />
                            </ListItem>
                          ))}
                        </List>
                      </Box>
                    </Box>
                  ))}
                </Box>
              </CardContent>
            </Card>
          ))}
        </Box>

        <Divider sx={{ mb: 4 }} />

        <Box mb={4}>
          <Typography variant="h5" gutterBottom>
            Documents
          </Typography>
          {globalDocuments.length > 0 ? (
            <List>
              {globalDocuments.map((doc, index) => (
                <ListItem key={index}>
                  <ListItemText primary={doc.name} secondary={doc.description} />
                </ListItem>
              ))}
            </List>
          ) : (
            <Typography>No documents available.</Typography>
          )}
        </Box>

        <Divider sx={{ mb: 4 }} />

        <Box mb={4}>
          <Typography variant="h5" gutterBottom>
            Inspection Reports
          </Typography>
          {globalElements.flatMap((element) => element.inspectionReport).length > 0 ? (
            <>
              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Element</TableCell>
                      <TableCell>Report Name</TableCell>
                      <TableCell>Description</TableCell>
                      <TableCell>Condition</TableCell>
                      <TableCell>Urgency</TableCell>
                      <TableCell>Type</TableCell>
                      <TableCell>Function</TableCell>
                      <TableCell>Unit</TableCell>
                      <TableCell>Estimated Price</TableCell>
                      <TableCell>Remarks</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {inspectionReportsData.map((report, index) => (
                      <TableRow key={index}>
                        <TableCell>{report.Element}</TableCell>
                        <TableCell>{report.ReportName}</TableCell>
                        <TableCell>{report.Description}</TableCell>
                        <TableCell>{report.Condition}</TableCell>
                        <TableCell>{report.Urgency}</TableCell>
                        <TableCell>{report.Type}</TableCell>
                        <TableCell>{report.Function}</TableCell>
                        <TableCell>{report.Unit}</TableCell>
                        <TableCell>{formatCurrency(report.EstimatedPrice)}</TableCell>
                        <TableCell>{report.Remarks}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
              <Box mt={2} display="flex" justifyContent="center">
                <Button variant="contained" onClick={() => exportToExcel(inspectionReportsData, 'Inspection_Reports')}>
                  Export to Excel
                </Button>
              </Box>
            </>
          ) : (
            <Typography>No inspection reports available.</Typography>
          )}
        </Box>

        <Divider sx={{ mb: 4 }} />

        <Box mb={4}>
          <Typography variant="h5" gutterBottom>
            Elements and Conditions
          </Typography>
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Name</TableCell>
                  <TableCell>Description</TableCell>
                  <TableCell>Condition</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {elementsData.map((element, index) => (
                  <TableRow key={index}>
                    <TableCell>{element.Name}</TableCell>
                    <TableCell>{element.Description}</TableCell>
                    <TableCell>{element.Condition}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <Box mt={2} display="flex" justifyContent="center">
            <Button variant="contained" onClick={() => exportToExcel(elementsData, 'Elements_Conditions')}>
              Export to Excel
            </Button>
          </Box>
        </Box>
      </Paper>
    </Container>
  );
};

export default ViewMJOP;
