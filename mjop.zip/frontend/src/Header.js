import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  AppBar,
  Toolbar,
  IconButton,
  Typography,
  Button,
  Menu,
  MenuItem,
  Tooltip,
  Box,
  Drawer,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Switch,
  FormControlLabel,
} from '@mui/material';
import { AccountCircle, Language, Menu as MenuIcon, Brightness4, Brightness7 } from '@mui/icons-material';
import { List as ListIcon, LogIn, UserPlus, LogOut, FilePlus } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const Header = ({ isAuthenticated, onLogout, toggleTheme, isDarkMode }) => {
  const { t, i18n } = useTranslation();
  const [anchorEl, setAnchorEl] = useState(null);
  const [langAnchorEl, setLangAnchorEl] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLangMenu = (event) => {
    setLangAnchorEl(event.currentTarget);
  };

  const handleLangClose = () => {
    setLangAnchorEl(null);
  };

  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
    handleLangClose();
  };

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const drawer = (
    <Box onClick={handleDrawerToggle} sx={{ textAlign: 'center' }}>
      <Typography variant="h6" sx={{ my: 2 }}>
        {t('header.title')}
      </Typography>
      <List>
        {isAuthenticated ? (
          <>
            <ListItem button component={Link} to="/mjop-list">
              <ListItemIcon>
                <ListIcon />
              </ListItemIcon>
              <ListItemText primary={t('header.mjopList')} />
            </ListItem>
            <ListItem button component={Link} to="/generate-mjop">
              <ListItemIcon>
                <FilePlus />
              </ListItemIcon>
              <ListItemText primary={t('header.generateMJOP')} />
            </ListItem>
            <ListItem button component={Link} to="/create-subuser">
              <ListItemIcon>
                <UserPlus />
              </ListItemIcon>
              <ListItemText primary={t('header.createSubuser')} />
            </ListItem>
            <ListItem button onClick={onLogout}>
              <ListItemIcon>
                <LogOut />
              </ListItemIcon>
              <ListItemText primary={t('header.logout')} />
            </ListItem>
          </>
        ) : (
          <>
            <ListItem button component={Link} to="/login">
              <ListItemIcon>
                <LogIn />
              </ListItemIcon>
              <ListItemText primary={t('header.login')} />
            </ListItem>
            <ListItem button component={Link} to="/register">
              <ListItemIcon>
                <UserPlus />
              </ListItemIcon>
              <ListItemText primary={t('header.register')} />
            </ListItem>
          </>
        )}
        <ListItem button onClick={() => changeLanguage('en')}>
          <ListItemIcon>
            <Language />
          </ListItemIcon>
          <ListItemText primary="EN" />
        </ListItem>
        <ListItem button onClick={() => changeLanguage('nl')}>
          <ListItemIcon>
            <Language />
          </ListItemIcon>
          <ListItemText primary="NL" />
        </ListItem>
        <ListItem>
          <FormControlLabel
            control={<Switch checked={isDarkMode} onChange={toggleTheme} />}
            label={isDarkMode ? t('header.lightMode') : t('header.darkMode')}
          />
        </ListItem>
      </List>
    </Box>
  );

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="fixed">
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { md: 'none' } }}
          >
            <MenuIcon />
          </IconButton>
          <img src="logo.png" className="w-12" alt="Logo" style={{ marginRight: '16px' }} />
          <Typography variant="h6" sx={{ flexGrow: 1, display: { xs: 'none', md: 'block' } }}>
            {t('header.title')}
          </Typography>
          <Box sx={{ display: { xs: 'none', md: 'flex' } }}>
            {isAuthenticated ? (
              <>
                <Tooltip title={t('header.mjopList')}>
                  <IconButton color="inherit" component={Link} to="/mjop-list">
                    <ListIcon />
                  </IconButton>
                </Tooltip>
                <Tooltip title={t('header.generateMJOP')}>
                  <IconButton color="inherit" component={Link} to="/generate-mjop">
                    <FilePlus />
                  </IconButton>
                </Tooltip>
                <Tooltip title={t('header.createSubuser')}>
                  <IconButton color="inherit" component={Link} to="/create-subuser">
                    <UserPlus />
                  </IconButton>
                </Tooltip>
                <IconButton color="inherit" onClick={handleMenu}>
                  <AccountCircle />
                </IconButton>
                <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleClose}>
                  <MenuItem onClick={onLogout}>{t('header.logout')}</MenuItem>
                </Menu>
              </>
            ) : (
              <>
                <Tooltip title={t('header.login')}>
                  <Button color="inherit" component={Link} to="/login">
                    {t('header.login')}
                  </Button>
                </Tooltip>
                <Tooltip title={t('header.register')}>
                  <Button color="inherit" component={Link} to="/register">
                    {t('header.register')}
                  </Button>
                </Tooltip>
              </>
            )}
            <Tooltip title={isDarkMode ? t('header.lightMode') : t('header.darkMode')}>
              <IconButton color="inherit" onClick={toggleTheme}>
                {isDarkMode ? <Brightness7 /> : <Brightness4 />}
              </IconButton>
            </Tooltip>
            <IconButton color="inherit" onClick={handleLangMenu}>
              <Language />
            </IconButton>
            <Menu anchorEl={langAnchorEl} open={Boolean(langAnchorEl)} onClose={handleLangClose}>
              <MenuItem onClick={() => changeLanguage('en')}>EN</MenuItem>
              <MenuItem onClick={() => changeLanguage('nl')}>NL</MenuItem>
            </Menu>
          </Box>
        </Toolbar>
      </AppBar>
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={handleDrawerToggle}
        ModalProps={{
          keepMounted: true,
        }}
        sx={{
          display: { xs: 'block', md: 'none' },
          '& .MuiDrawer-paper': { boxSizing: 'border-box', width: 240 },
        }}
      >
        {drawer}
      </Drawer>
    </Box>
  );
};

export default Header;
