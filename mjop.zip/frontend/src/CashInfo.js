import React, { useState, useEffect } from 'react';
import { TextField, Grid, Box, Typography, FormControl, InputLabel, FormHelperText } from '@mui/material';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const CashInfo = ({ cashInfo, setCashInfo, errors, calculateCurrentCash, getSaldoColor, globalElements, t }) => {
  const [localErrors, setLocalErrors] = useState({});

  const validateFields = () => {
    const newErrors = {};
    if (!cashInfo.currentCash) newErrors.currentCash = t('generateMJOP.errorCurrentCash');
    if (!cashInfo.monthlyContribution) newErrors.monthlyContribution = t('generateMJOP.errorMonthlyContribution');
    if (!cashInfo.reserveDate) newErrors.reserveDate = t('generateMJOP.errorReserveDate');
    if (!cashInfo.totalWorth) newErrors.totalWorth = t('generateMJOP.errorTotalWorth');
    setLocalErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  useEffect(() => {
    validateFields();
  }, [cashInfo]);

  const handleInputChange = (field, value) => {
    setCashInfo((prev) => ({ ...prev, [field]: value }));
    setLocalErrors((prevErrors) => ({ ...prevErrors, [field]: null }));
  };

  const handleDateChange = (date) => {
    setCashInfo((prev) => ({ ...prev, reserveDate: date }));
    setLocalErrors((prevErrors) => ({ ...prevErrors, reserveDate: null }));
  };

  useEffect(() => {
    calculateCurrentCash(cashInfo, globalElements);
  }, [cashInfo, globalElements, calculateCurrentCash]);

  return (
    <Box component="section" sx={{ mt: 4 }}>
      <Typography variant="h5" component="h3" sx={{ mb: 2 }}>
        {t('generateMJOP.cashInfo')}
      </Typography>
      <Grid container spacing={2}>
        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            type="number"
            label={t('generateMJOP.currentCash')}
            placeholder={t('generateMJOP.currentCashPlaceholder')}
            variant="outlined"
            value={cashInfo.currentCash}
            onChange={(e) => handleInputChange('currentCash', e.target.value)}
            error={!!localErrors.currentCash}
            helperText={localErrors.currentCash}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            type="number"
            label={t('generateMJOP.monthlyContribution')}
            placeholder={t('generateMJOP.monthlyContributionPlaceholder')}
            variant="outlined"
            value={cashInfo.monthlyContribution}
            onChange={(e) => handleInputChange('monthlyContribution', e.target.value)}
            error={!!localErrors.monthlyContribution}
            helperText={localErrors.monthlyContribution}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <FormControl fullWidth>
            <InputLabel shrink>{t('generateMJOP.reserveDate')}</InputLabel>
            <DatePicker
              selected={cashInfo.reserveDate ? new Date(cashInfo.reserveDate) : null}
              onChange={handleDateChange}
              dateFormat="dd/MM/yyyy"
              customInput={<TextField fullWidth variant="outlined" />}
              placeholderText={t('generateMJOP.reserveDatePlaceholder')}
            />
            {localErrors.reserveDate && <FormHelperText error>{localErrors.reserveDate}</FormHelperText>}
          </FormControl>
        </Grid>
        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            type="number"
            label={t('generateMJOP.totalWorth')}
            placeholder={t('generateMJOP.totalWorthPlaceholder')}
            variant="outlined"
            value={cashInfo.totalWorth}
            onChange={(e) => handleInputChange('totalWorth', e.target.value)}
            error={!!localErrors.totalWorth}
            helperText={localErrors.totalWorth}
          />
        </Grid>
      </Grid>
      <Box sx={{ mt: 4 }}>
        <Typography variant="body1" component="label" sx={{ display: 'block', mb: 1 }}>
          {t('generateMJOP.calculatedCurrentCash')}
        </Typography>
        <TextField
          fullWidth
          value={calculateCurrentCash(cashInfo, globalElements)}
          variant="outlined"
          InputProps={{
            readOnly: true,
            className: `${getSaldoColor(calculateCurrentCash(cashInfo, globalElements), cashInfo.totalWorth)} text-white`,
          }}
        />
      </Box>
      <Typography variant="body2" color="textSecondary" sx={{ mt: 2 }}>
        {t('generateMJOP.cashInfoExplanation')}
      </Typography>
    </Box>
  );
};

export default CashInfo;
